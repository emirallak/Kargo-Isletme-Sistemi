CREATE DATABASE IF NOT EXISTS kocaeli_kargo;
USE kocaeli_kargo;

-- İstasyonlar (İlçeler) Tablosu
CREATE TABLE IF NOT EXISTS stations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    distance_to_center DECIMAL(10, 2) DEFAULT 0 -- Umuttepe'ye olan uzaklık (cache)
);

-- Araçlar Tablosu
CREATE TABLE IF NOT EXISTS vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plate VARCHAR(20) UNIQUE,
    capacity INT NOT NULL, -- 500, 750, 1000
    type ENUM('ozmal', 'kiralik') DEFAULT 'ozmal',
    cost_per_km DECIMAL(10, 2) DEFAULT 1.0,
    fixed_cost DECIMAL(10, 2) DEFAULT 0.0 -- Kiralık araçlar için 200
);

-- Seferler/Rotalar Tablosu (Eski - kullanılmıyor)
CREATE TABLE IF NOT EXISTS routes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT,
    route_path TEXT, -- JSON formatında sıralı istasyon ID'leri: [1, 5, 3, 1]
    total_distance DECIMAL(10, 2),
    total_cost DECIMAL(10, 2),
    cargo_load DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
);

-- Rota Hesaplamaları Tablosu (YENİ)
CREATE TABLE IF NOT EXISTS route_calculations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scenario_type VARCHAR(50) DEFAULT 'optimized',
    total_cost DECIMAL(10, 2),
    vehicle_count INT,
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Rota Araçları Tablosu (YENİ)
CREATE TABLE IF NOT EXISTS route_vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    calculation_id INT,
    vehicle_id INT,
    vehicle_type ENUM('ozmal', 'kiralik') DEFAULT 'ozmal',
    capacity INT,
    current_load DECIMAL(10, 2),
    distance_km DECIMAL(10, 2),
    cost DECIMAL(10, 2),
    route_stations_json TEXT,
    path_coords_json LONGTEXT,
    FOREIGN KEY (calculation_id) REFERENCES route_calculations(id) ON DELETE CASCADE
);

-- Kullanıcılar Tablosu
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Kargolar Tablosu
CREATE TABLE IF NOT EXISTS cargos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    station_id INT,
    weight DECIMAL(10, 2) NOT NULL,
    description TEXT,
    status ENUM('pending', 'assigned', 'delivered', 'cancelled') DEFAULT 'pending',
    route_vehicle_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (station_id) REFERENCES stations(id),
    FOREIGN KEY (route_vehicle_id) REFERENCES route_vehicles(id) ON DELETE SET NULL
);

-- Başlangıç Verileri (İlçeler - Yaklaşık Koordinatlar)
INSERT IGNORE INTO stations (name, latitude, longitude) VALUES 
('Basiskele', 40.715, 29.928),
('Cayirova', 40.815, 29.375),
('Darica', 40.773, 29.400),
('Derince', 40.756, 29.830),
('Dilovasi', 40.787, 29.544),
('Gebze', 40.802, 29.430),
('Golcuk', 40.717, 29.820),
('Kandira', 41.070, 30.150),
('Karamursel', 40.692, 29.615),
('Kartepe', 40.753, 30.020),
('Korfez', 40.765, 29.780),
('Izmit', 40.766, 29.940),
('Umuttepe_Merkez', 40.822, 29.922); -- Kocaeli Üni.

-- Admin kullanıcısı
INSERT IGNORE INTO users (username, password, role) VALUES ('admin', 'admin123', 'admin');
