import mysql.connector

conn = mysql.connector.connect(
    host='localhost', 
    user='root', 
    password='ardahan75', 
    database='kocaeli_kargo'
)
cursor = conn.cursor()

# route_calculations tablosu
cursor.execute('''
CREATE TABLE IF NOT EXISTS route_calculations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scenario_type VARCHAR(50) DEFAULT 'optimized',
    total_cost DECIMAL(10, 2),
    vehicle_count INT,
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
''')

# route_vehicles tablosu
cursor.execute('''
CREATE TABLE IF NOT EXISTS route_vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    calculation_id INT,
    vehicle_id INT,
    vehicle_type VARCHAR(20) DEFAULT 'ozmal',
    capacity INT,
    current_load DECIMAL(10, 2),
    distance_km DECIMAL(10, 2),
    cost DECIMAL(10, 2),
    route_stations_json TEXT,
    path_coords_json LONGTEXT
)
''')

conn.commit()
print('Tablolar basariyla olusturuldu!')

# Mevcut kayitlari kontrol et
cursor.execute('SELECT COUNT(*) FROM route_calculations')
print(f'route_calculations: {cursor.fetchone()[0]} kayit')

cursor.execute('SELECT COUNT(*) FROM route_vehicles')
print(f'route_vehicles: {cursor.fetchone()[0]} kayit')

conn.close()
