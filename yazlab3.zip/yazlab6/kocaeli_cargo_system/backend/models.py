class Station:
    def __init__(self, id, name, lat, lon, cargo_weight=0, cargo_count=0):
        self.id = id
        self.name = name
        self.lat = lat
        self.lon = lon
        self.cargo_weight = cargo_weight
        self.cargo_count = cargo_count
        self.node_id = None # OSM Node ID

    def __repr__(self):
        return f"{self.name} ({self.cargo_weight}kg)"

class Vehicle:
    def __init__(self, id, capacity, v_type='ozmal'):
        self.id = id
        self.capacity = capacity
        self.current_load = 0
        self.v_type = v_type # 'ozmal' veya 'kiralik'
        self.route = [] # Ziyaret edilecek istasyon listesi
        self.total_km = 0
        
    @property
    def cost(self):
        # Formül: (Yol * 1) + (Kiralama * 200)
        rent_cost = 200 if self.v_type == 'kiralik' else 0
        return (self.total_km * 1) + rent_cost

    def can_load(self, weight):
        return (self.current_load + weight) <= self.capacity

    def load_cargo(self, weight):
        if self.can_load(weight):
            self.current_load += weight
            return True
        return False
