from flask import Flask, jsonify, request, render_template, redirect, url_for, session, flash
from functools import wraps
import mysql.connector
import json
from datetime import datetime
import os
import sys
import math

# Model importları (Dosya yapısını korumak için)
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from models import Station, Vehicle

app = Flask(__name__,
            template_folder='../templates',
            static_folder='../static')
app.secret_key = 'kocaeli_kargo_secret_key_2025'

# ==================== VERİTABANI AYARLARI ====================
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'ardahan75',  # Senin şifren
    'database': 'kocaeli_kargo'
}


def get_db_connection():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except mysql.connector.Error as err:
        print(f"Veritabanı bağlantı hatası: {err}")
        return None


# ==================== GLOBAL DEĞİŞKENLER & HELPERS ====================

# Global Koordinat Cache'i
COORDS = {}

def refresh_coords():
    """Veritabanından koordinatları çekip global değişkene yükler"""
    global COORDS
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT name, lat, lon FROM stations WHERE is_active = 1")
        rows = cursor.fetchall()
        COORDS = {row['name']: (row['lat'], row['lon']) for row in rows}
        # Depo koordinatını manuel ekle/garantiye al
        COORDS['Umuttepe'] = (40.822, 29.922)
        cursor.close()
        conn.close()


# Uygulama başlarken koordinatları yükle
refresh_coords()


def get_stations_from_db():
    conn = get_db_connection()
    stations = []
    if conn:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM stations WHERE is_active = 1 ORDER BY id")
        rows = cursor.fetchall()
        for row in rows:
            st = Station(row['id'], row['name'], row['lat'], row['lon'])
            stations.append(st)
        cursor.close()
        conn.close()
    return stations


def haversine(lat1, lon1, lat2, lon2):
    R = 6371
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * R * math.atan2(math.sqrt(a), math.sqrt(1 - a))


# Global OSM Helper (Lazy Loading)
osm_helper = None


def get_osm_helper():
    global osm_helper
    if osm_helper is None:
        try:
            from osm_helper import OSMHelper
            print("🗺️ OpenStreetMap verisi yükleniyor...")
            osm_helper = OSMHelper("Kocaeli, Turkey")
        except ImportError:
            print("⚠️ OSMHelper bulunamadı veya yüklenemedi.")
    return osm_helper


# ==================== DECORATORS ====================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Bu sayfayı görüntülemek için giriş yapmalısınız.', 'warning')
            return redirect(url_for('home'))
        return f(*args, **kwargs)

    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            flash('Bu sayfa sadece yöneticiler içindir.', 'danger')
            return redirect(url_for('home'))
        return f(*args, **kwargs)

    return decorated_function


# ==================== ROTA & SAYFA YÖNETİMİ ====================

@app.route('/')
def home():
    if 'user_id' in session:
        if session.get('role') == 'admin':
            return redirect(url_for('admin_panel'))
        else:
            return redirect(url_for('user_panel'))
    return render_template('index.html')


@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        # Not: Gerçek uygulamada password hash kullanılmalı
        cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s AND role = 'admin'",
                       (username, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = 'admin'
            flash('Yönetici girişi başarılı!', 'success')
            return redirect(url_for('admin_panel'))
        else:
            flash('Geçersiz yönetici bilgileri!', 'danger')

    return render_template('admin_login.html')


@app.route('/user/login', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'register':
            username = request.form.get('username')
            password = request.form.get('password')
            email = request.form.get('email')

            conn = get_db_connection()
            try:
                cursor = conn.cursor()
                cursor.execute("INSERT INTO users (username, password, email, role) VALUES (%s, %s, %s, 'user')",
                               (username, password, email))
                conn.commit()
                flash('Kayıt başarılı! Şimdi giriş yapabilirsiniz.', 'success')
            except mysql.connector.IntegrityError:
                flash('Bu kullanıcı adı zaten kullanılıyor!', 'danger')
            finally:
                conn.close()

        else:  # Login
            username = request.form.get('username')
            password = request.form.get('password')

            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
            user = cursor.fetchone()
            conn.close()

            if user:
                session['user_id'] = user['id']
                session['username'] = user['username']
                session['role'] = user['role']
                flash(f'Hoşgeldin {user["username"]}!', 'success')
                return redirect(url_for('user_panel'))
            else:
                flash('Hatalı kullanıcı adı veya şifre!', 'danger')

    return render_template('user_login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Çıkış yapıldı.', 'info')
    return redirect(url_for('home'))


@app.route('/admin')
@admin_required
def admin_panel():
    # 1. Tüm istasyonları çek
    stations = get_stations_from_db()

    # 2. Veritabanından SADECE BUGÜNKÜ ve BEKLEYEN (Pending) kargoları özetle
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        query = """
            SELECT s.name, SUM(c.weight) as total_weight, COUNT(c.id) as total_count
            FROM cargos c
            JOIN stations s ON c.station_id = s.id
            WHERE c.status = 'pending' 
            GROUP BY s.name
        """
        cursor.execute(query)
        results = cursor.fetchall()

        # Sonuçları hızlı erişim için sözlüğe çevir: {'Gebze': {'total_weight': 50, ...}, ...}
        summary = {row['name']: row for row in results}

    except Exception as e:
        print(f"Admin paneli veri çekme hatası: {e}")
        summary = {}
    finally:
        conn.close()

    # 3. İstasyon objelerine bu verileri ekle (HTML'de value="{{ s.cargo_weight }}" ile görünecek)
    for s in stations:
        if s.name in summary:
            s.cargo_weight = int(summary[s.name]['total_weight'])
            s.cargo_count = summary[s.name]['total_count']
        else:
            s.cargo_weight = 0
            s.cargo_count = 0

    return render_template('admin_panel.html', stations=stations)
@app.route('/user')
@login_required
def user_panel():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Kullanıcının kargoları
    query = """
        SELECT c.*, s.name as station_name 
        FROM cargos c
        JOIN stations s ON c.station_id = s.id
        WHERE c.user_id = %s
        ORDER BY c.created_at DESC
    """
    cursor.execute(query, (session['user_id'],))
    user_cargos = cursor.fetchall()
    conn.close()

    stations = get_stations_from_db()
    stations = [s for s in stations if s.name != 'Umuttepe']

    return render_template('user_panel.html', stations=stations, user_cargos=user_cargos)


@app.route('/user/send_cargo', methods=['POST'])
@login_required
def user_send_cargo():
    station_id = request.form.get('station_id')
    weight = request.form.get('weight')
    description = request.form.get('description', '')

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO cargos (user_id, station_id, weight, description, status)
            VALUES (%s, %s, %s, %s, 'pending')
        """, (session['user_id'], station_id, weight, description))
        conn.commit()
        flash('Kargo talebiniz alındı! Yönetici onayı bekliyor.', 'success')
    except Exception as e:
        flash(f'Hata oluştu: {str(e)}', 'danger')
    finally:
        conn.close()

    return redirect(url_for('user_panel'))


# ==================== API ENDPOINTS ====================

@app.route('/api/stations', methods=['GET', 'POST'])
def api_stations():
    conn = get_db_connection()

    if request.method == 'POST':
        data = request.json
        try:
            cursor = conn.cursor()
            # ID'yi otomatik artırmasını beklemiyoruz, manuel kontrol gerekebilir veya auto_increment
            # Burada tablonun auto_increment olduğunu varsayıyoruz, değilse:
            cursor.execute("INSERT INTO stations (name, lat, lon, is_active) VALUES (%s, %s, %s, 1)",
                           (data['name'], data['lat'], data['lon']))
            conn.commit()
            refresh_coords()
            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
        finally:
            conn.close()

    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM stations WHERE is_active=1")
    stations = cursor.fetchall()
    conn.close()
    return jsonify(stations)


@app.route('/api/stations/<int:station_id>', methods=['DELETE'])
@admin_required
def api_delete_station(station_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE stations SET is_active=0 WHERE id=%s", (station_id,))
    conn.commit()
    conn.close()
    refresh_coords()
    return jsonify({'success': True})


# ==================== ROTA HESAPLAMA VE ÇÖZME API'Sİ ====================

@app.route('/api/solve', methods=['POST'])
@admin_required
def solve_scenario():
    print("\n🚀 Rota Hesaplama İsteği Geldi...")
    data = request.json
    scenario_type = data.get('scenario', 'both')

    # Frontend'den gelen verileri al
    input_cargos = data.get('cargos', [])

    # Eğer frontend boş liste gönderdiyse (Genelde "Hesapla" butonuna basınca boş gelir)
    # Veritabanından durumu SADECE 'pending' olanları çekmeliyiz.
    if not input_cargos:
        print("📥 Frontend kargo göndermedi, DB'den 'pending' kargolar çekiliyor...")
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # --- KRİTİK SORGU GÜNCELLEMESİ ---
        # 1. status = 'pending': Sadece beklemedeki kargoları al.
        # 2. (Opsiyonel) DATE(created_at) = CURDATE(): Sadece BUGÜN girilenleri al (Eski test verilerini temizlemek için).
        cursor.execute("""
            SELECT c.id, c.weight, s.name as station_name 
            FROM cargos c 
            JOIN stations s ON c.station_id = s.id 
            WHERE c.status = 'pending' 
            AND DATE(c.created_at) = CURDATE()
        """)
        # ---------------------------------

        db_rows = cursor.fetchall()
        conn.close()

        input_cargos = []
        for row in db_rows:
            input_cargos.append({
                'id': row['id'],
                'station_name': row['station_name'],
                'weight': row['weight']
            })
        print(f"📦 DB'den {len(input_cargos)} adet BEKLEYEN kargo bulundu.")

    if not input_cargos:
        print("❌ Hesaplanacak uygun kargo yok!")
        return jsonify({"error": "Hesaplanacak 'beklemede' (pending) kargo bulunamadı!"}), 400

    # 2. Algoritmayı Çalıştır
    print("🧮 Algoritma çalıştırılıyor...")
    results = run_advanced_algorithm(input_cargos, scenario_type)

    # 3. Sonuçları Veritabanına Kaydet
    # Hesaplama başarılıysa, bu kargoların durumunu 'assigned' yapacağız ki bir daha gelmesinler.
    if 'best_scenario' in results:
        print("💾 Sonuçlar veritabanına kaydediliyor...")
        save_calculation_to_db(results['best_scenario'], input_cargos)
    else:
        print("❌ Uygun senaryo bulunamadığı için kayıt yapılmadı.")

    return jsonify(results)


def run_advanced_algorithm(cargos, scenario_type):
    """
    Tüm olasılıkları (1 Araç, 2 Araç, Kiralık vb.) hesaplar.
    """
    # İstasyon bazlı toplam ağırlık hesapla
    station_weights = {}
    for c in cargos:
        st = c['station_name']
        station_weights[st] = station_weights.get(st, 0) + c['weight']

    all_stations = list(station_weights.keys())
    total_weight = sum(station_weights.values())

    osm = get_osm_helper()

    all_scenarios = []

    # --- YARDIMCI FONKSİYONLAR ---
    def get_dist(s1, s2):
        if osm:
            # Basit cache mekanizması eklenebilir
            c1 = COORDS.get(s1, COORDS['Umuttepe'])
            c2 = COORDS.get(s2, COORDS['Umuttepe'])
            try:
                d, _ = osm.get_distance_and_path(c1[0], c1[1], c2[0], c2[1])
                return d
            except:
                pass
        # Fallback
        c1 = COORDS.get(s1, (0, 0))
        c2 = COORDS.get(s2, (0, 0))
        return haversine(c1[0], c1[1], c2[0], c2[1]) * 1.3

    def solve_route(stations_to_visit):
        # Nearest Neighbor
        if not stations_to_visit: return [], 0

        current = 'Umuttepe'
        route = ['Umuttepe']
        unvisited = stations_to_visit.copy()
        total_d = 0

        while unvisited:
            nearest = min(unvisited, key=lambda s: get_dist(current, s))
            total_d += get_dist(current, nearest)
            route.append(nearest)
            current = nearest
            unvisited.remove(nearest)

        total_d += get_dist(current, 'Umuttepe')
        route.append('Umuttepe')
        return route, round(total_d, 2)

    def get_path_coords(route):
        if not osm or len(route) < 2: return []
        coords = [COORDS.get(s, COORDS['Umuttepe']) for s in route]
        _, path = osm.get_full_route_path(coords)
        return path

    # --- SENARYOLAR ---

    # Senaryo A: Tek Araç (Eğer sığıyorsa)
    capacities = [1000, 750, 500]
    for cap in capacities:
        if total_weight <= cap:
            route, dist = solve_route(all_stations)
            all_scenarios.append({
                'name': f'1 Araç ({cap}kg)',
                'total_cost': dist,
                'vehicle_count': 1,
                'rental_count': 0,
                'vehicles': [{
                    'vehicle_id': 1, 'type': 'ozmal', 'capacity': cap, 'load': total_weight,
                    'route': route, 'distance_km': dist, 'cost': dist,
                    'path_coords': get_path_coords(route)
                }]
            })

    # Senaryo B: Çoklu Araç (Best Fit Decreasing - Özmal Öncelikli)
    # Özmal araçlar: 1000kg, 750kg, 500kg
    ozmal_vehicles = [
        {'id': 1, 'cap': 1000, 'type': 'ozmal', 'load': 0, 'stations': []},
        {'id': 2, 'cap': 750, 'type': 'ozmal', 'load': 0, 'stations': []},
        {'id': 3, 'cap': 500, 'type': 'ozmal', 'load': 0, 'stations': []}
    ]

    # Yükleri büyükten küçüğe sırala
    sorted_stations = sorted(station_weights.items(), key=lambda x: x[1], reverse=True)

    rental_vehicles = []  # Kiralık araçlar listesi
    rental_count = 0

    for st, weight in sorted_stations:
        remaining_weight = weight
        
        # Önce özmal araçlara sığdırmayı dene (Best Fit - en az boşluk kalana)
        while remaining_weight > 0:
            best_fit_vehicle = None
            best_fit_remaining = float('inf')
            best_fit_amount = 0
            
            # Özmal araçlarda yer ara
            for v in ozmal_vehicles:
                space = v['cap'] - v['load']
                if space > 0:
                    can_load = min(remaining_weight, space)
                    # En iyi uyumu bul (en az boşluk kalacak şekilde)
                    if space < best_fit_remaining:
                        best_fit_vehicle = v
                        best_fit_remaining = space
                        best_fit_amount = can_load
            
            if best_fit_vehicle and best_fit_amount > 0:
                best_fit_vehicle['load'] += best_fit_amount
                if st not in best_fit_vehicle['stations']:
                    best_fit_vehicle['stations'].append(st)
                remaining_weight -= best_fit_amount
            else:
                # Özmal araçlarda yer kalmadı, kiralık araç kullan
                break
        
        # Kalan ağırlık için kiralık araç kullan
        while remaining_weight > 0:
            placed_in_existing = False
            
            # Mevcut kiralık araçlarda yer ara
            for rv in rental_vehicles:
                space = rv['cap'] - rv['load']
                if space > 0:
                    can_load = min(remaining_weight, space)
                    rv['load'] += can_load
                    if st not in rv['stations']:
                        rv['stations'].append(st)
                    remaining_weight -= can_load
                    placed_in_existing = True
                    break
            
            # Mevcut kiralıklarda yer yoksa yeni kiralık araç ekle
            if not placed_in_existing and remaining_weight > 0:
                rental_count += 1
                can_load = min(remaining_weight, 500)  # Kiralık araç kapasitesi 500kg
                rental_vehicles.append({
                    'id': 100 + rental_count, 
                    'cap': 500, 
                    'type': 'kiralik',
                    'load': can_load, 
                    'stations': [st]
                })
                remaining_weight -= can_load

    # Tüm araçları birleştir
    all_used_vehicles = ozmal_vehicles + rental_vehicles

    # Boş olmayan araçları hesapla
    active_vehicles_data = []
    total_scenario_cost = 0

    for v in all_used_vehicles:
        if v['stations']:
            route, dist = solve_route(v['stations'])
            # Kiralık araç maliyeti: mesafe + 200 sabit ücret
            cost = dist + (200 if v.get('type') == 'kiralik' else 0)
            total_scenario_cost += cost

            active_vehicles_data.append({
                'vehicle_id': v['id'],
                'type': v.get('type', 'ozmal'),
                'capacity': v['cap'],
                'load': v['load'],
                'route': route,
                'distance_km': dist,
                'cost': cost,
                'path_coords': get_path_coords(route)
            })

    if active_vehicles_data:
        all_scenarios.append({
            'name': f'Filo Dağıtımı ({len(active_vehicles_data)} Araç)',
            'total_cost': round(total_scenario_cost, 2),
            'vehicle_count': len(active_vehicles_data),
            'rental_count': rental_count,
            'vehicles': active_vehicles_data
        })

    # Senaryo C: Sadece Özmal Araçlar (3 Araç Limiti)
    # Bu senaryo, kapasite aşılırsa bazı kargoları reddeder
    ozmal_only = [
        {'id': 1, 'cap': 1000, 'type': 'ozmal', 'load': 0, 'stations': []},
        {'id': 2, 'cap': 750, 'type': 'ozmal', 'load': 0, 'stations': []},
        {'id': 3, 'cap': 500, 'type': 'ozmal', 'load': 0, 'stations': []}
    ]
    
    rejected_stations = []
    rejected_weight = 0
    accepted_weight = 0
    
    for st, weight in sorted_stations:
        placed = False
        
        # Best Fit
        best_v = None
        best_remaining = float('inf')
        
        for v in ozmal_only:
            remaining = v['cap'] - v['load']
            if weight <= remaining and remaining < best_remaining:
                best_v = v
                best_remaining = remaining - weight
        
        if best_v:
            best_v['load'] += weight
            best_v['stations'].append(st)
            accepted_weight += weight
            placed = True
        else:
            rejected_stations.append(st)
            rejected_weight += weight
    
    # Özmal araçları hesapla
    ozmal_vehicles_data = []
    ozmal_total_cost = 0
    
    for v in ozmal_only:
        if v['stations']:
            route, dist = solve_route(v['stations'])
            ozmal_total_cost += dist
            ozmal_vehicles_data.append({
                'vehicle_id': v['id'],
                'type': 'ozmal',
                'capacity': v['cap'],
                'load': v['load'],
                'route': route,
                'distance_km': dist,
                'cost': dist,
                'path_coords': get_path_coords(route)
            })
    
    if ozmal_vehicles_data:
        all_scenarios.append({
            'name': f'Sadece Özmal (3 Araç)',
            'total_cost': round(ozmal_total_cost, 2),
            'vehicle_count': len(ozmal_vehicles_data),
            'rental_count': 0,
            'rejected_weight': rejected_weight,
            'rejected_stations': rejected_stations,
            'accepted_weight': accepted_weight,
            'total_count': len(sorted_stations),
            'accepted_count': len(sorted_stations) - len(rejected_stations),
            'vehicles': ozmal_vehicles_data
        })

    # En iyiyi seç
    if not all_scenarios: 
        return {'error': 'Çözüm bulunamadı'}

    # DEBUG: Tüm senaryoları yazdır
    print(f"\n📊 TOPLAM AĞIRLIK: {total_weight}kg")
    print(f"📊 ÖZMAL KAPASİTE: 2250kg (1000+750+500)")
    for s in all_scenarios:
        rejected = s.get('rejected_weight', 0)
        rental = s.get('rental_count', 0)
        print(f"   - {s['name']}: Maliyet={s['total_cost']}, Kiralık={rental}, Reddedilen={rejected}kg")

    # UNLIMITED: Tüm kargoları taşıyabilen senaryolar (rejected_weight = 0 veya yok)
    # Kiralık araç kullanabilir, önemli olan tüm kargoların taşınması
    unlimited_scenarios = [s for s in all_scenarios if s.get('rejected_weight', 0) == 0]
    
    # Eğer tüm kargoları taşıyan senaryo yoksa, en az reddeden seçilir
    if not unlimited_scenarios:
        unlimited_scenarios = sorted(all_scenarios, key=lambda x: x.get('rejected_weight', 0))
    
    best_unlimited = min(unlimited_scenarios, key=lambda x: x['total_cost']) if unlimited_scenarios else None
    print(f"✅ UNLIMITED için seçilen: {best_unlimited['name'] if best_unlimited else 'YOK'}")

    # LIMITED: Sadece özmal araçlar (kiralık yok, bazı kargolar reddedilebilir)
    ozmal_scenario = next((s for s in all_scenarios if 'Sadece Özmal' in s.get('name', '')), None)
    if not ozmal_scenario:
        limited_scenarios = [s for s in all_scenarios if s.get('rental_count', 0) == 0]
        best_limited = min(limited_scenarios, key=lambda x: x['total_cost']) if limited_scenarios else None
    else:
        best_limited = ozmal_scenario
    print(f"✅ LIMITED için seçilen: {best_limited['name'] if best_limited else 'YOK'}")

    # scenario_type'a göre best_scenario belirle
    if scenario_type == 'limited':
        # Sadece özmal araçlar - reddedilen kargolarla birlikte
        best_scenario = best_limited if best_limited else min(all_scenarios, key=lambda x: x['total_cost'])
        print(f"🎯 SEÇİLEN SENARYO (limited): {best_scenario['name']}")
    elif scenario_type == 'unlimited':
        # Kiralık dahil, TÜM KARGOLARI taşıyabilen en iyi senaryo
        best_scenario = best_unlimited if best_unlimited else min(all_scenarios, key=lambda x: x['total_cost'])
        print(f"🎯 SEÇİLEN SENARYO (unlimited): {best_scenario['name']}")
    else:
        # both - tüm kargoları taşıyabilen en iyi (unlimited gibi davran)
        best_scenario = best_unlimited if best_unlimited else min(all_scenarios, key=lambda x: x['total_cost'])
        print(f"🎯 SEÇİLEN SENARYO (both): {best_scenario['name']}")

    # Frontend formatı için:
    result = {
        'vehicles': best_scenario['vehicles'],
        'total_cost': best_scenario['total_cost'],
        'total_weight': total_weight,
        'best_scenario': best_scenario,
        'all_scenarios': all_scenarios,
        'scenario_type': scenario_type
    }
    
    if best_unlimited:
        result['unlimited'] = best_unlimited
    if best_limited:
        result['limited'] = best_limited
    
    return result


def save_calculation_to_db(best_scenario, input_cargos):
    """Hesaplama sonucunu kaydeder ve kargo durumlarını günceller"""
    print("--- DB KAYIT İŞLEMİ BAŞLIYOR ---")
    conn = get_db_connection()
    if not conn:
        print("❌ DB Bağlantısı kurulamadı!")
        return

    cursor = conn.cursor()

    try:
        # 1. Calculation Kaydı
        cursor.execute("""
            INSERT INTO route_calculations (scenario_type, total_cost, vehicle_count, calculated_at)
            VALUES ('optimized', %s, %s, NOW())
        """, (best_scenario['total_cost'], len(best_scenario['vehicles'])))
        calc_id = cursor.lastrowid
        print(f"✅ Calculation ID oluşturuldu: {calc_id}")

        # 2. Araçları Kaydet ve Kargoları Güncelle
        for v in best_scenario['vehicles']:
            vehicle_type = v.get('type', 'ozmal')

            # JSON dönüşümleri
            route_json = json.dumps(v['route'])
            path_json = json.dumps(v['path_coords'])

            cursor.execute("""
                INSERT INTO route_vehicles 
                (calculation_id, vehicle_id, vehicle_type, capacity, current_load, distance_km, cost, 
                route_stations_json, path_coords_json)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                calc_id, v['vehicle_id'], vehicle_type, v['capacity'], v['load'], v['distance_km'], v['cost'],
                route_json, path_json
            ))
            rv_id = cursor.lastrowid
            print(f"  👉 Araç Eklendi (ID: {v['vehicle_id']}, DB_ID: {rv_id}) -> Rotası: {v['route']}")

            # BU ARACIN GİTTİĞİ İSTASYONLARDAKİ BEKLEYEN KARGOLARI ATA
            for station_name in v['route']:
                if station_name == 'Umuttepe': continue

                print(f"     🔄 '{station_name}' istasyonundaki kargolar güncelleniyor...")

                # Güncelleme sorgusu
                update_query = """
                    UPDATE cargos 
                    SET status = 'assigned', 
                        route_vehicle_id = %s, 
                        updated_at = NOW()
                    WHERE status = 'pending' 
                    AND station_id = (SELECT id FROM stations WHERE name = %s LIMIT 1)
                """
                cursor.execute(update_query, (rv_id, station_name))
                affected = cursor.rowcount
                print(f"     ✅ {affected} adet kargo güncellendi.")

        conn.commit()
        print("✅ TÜM İŞLEMLER BAŞARIYLA KAYDEDİLDİ.")

    except Exception as e:
        print(f"❌ DB KAYIT HATASI OLUŞTU: {e}")
        conn.rollback()
        print("⚠️ İşlemler geri alındı (Rollback).")
    finally:
        cursor.close()
        conn.close()
        print("--- DB BAĞLANTISI KAPATILDI ---")


# ==================== ROTA LİSTELEME API ====================

@app.route('/api/routes')
@admin_required
def get_all_routes():
    """Tüm kayıtlı rotaları listeler"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Veritabanı bağlantısı kurulamadı'}), 500
    
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Tüm hesaplamaları getir
        cursor.execute("""
            SELECT id, scenario_type, total_cost, vehicle_count, calculated_at
            FROM route_calculations
            ORDER BY id DESC
        """)
        calculations = cursor.fetchall()
        
        routes_list = []
        for calc in calculations:
            # Her hesaplama için araçları getir
            cursor.execute("""
                SELECT id, vehicle_id, vehicle_type, capacity, current_load, 
                       distance_km, cost, route_stations_json, path_coords_json
                FROM route_vehicles
                WHERE calculation_id = %s
                ORDER BY vehicle_id
            """, (calc['id'],))
            vehicles = cursor.fetchall()
            
            vehicles_data = []
            for v in vehicles:
                vehicles_data.append({
                    'db_id': v['id'],
                    'vehicle_id': v['vehicle_id'],
                    'type': v['vehicle_type'],
                    'capacity': v['capacity'],
                    'load': float(v['current_load']) if v['current_load'] else 0,
                    'distance_km': float(v['distance_km']) if v['distance_km'] else 0,
                    'cost': float(v['cost']) if v['cost'] else 0,
                    'route': json.loads(v['route_stations_json']) if v['route_stations_json'] else [],
                    'path_coords': json.loads(v['path_coords_json']) if v['path_coords_json'] else []
                })
            
            routes_list.append({
                'id': calc['id'],
                'scenario_type': calc['scenario_type'],
                'total_cost': float(calc['total_cost']) if calc['total_cost'] else 0,
                'vehicle_count': calc['vehicle_count'],
                'calculated_at': calc['calculated_at'].strftime('%d.%m.%Y %H:%M') if calc['calculated_at'] else '',
                'vehicles': vehicles_data
            })
        
        return jsonify({'success': True, 'routes': routes_list})
        
    except Exception as e:
        print(f"Rota listeleme hatası: {e}")
        return jsonify({'success': False, 'error': str(e), 'routes': []}), 200
    finally:
        cursor.close()
        conn.close()


@app.route('/api/routes/<int:route_id>', methods=['DELETE'])
@admin_required
def delete_route(route_id):
    """Bir rotayı siler"""
    conn = get_db_connection()
    if not conn:
        return jsonify({'success': False, 'error': 'Veritabanı bağlantısı kurulamadı'}), 500
    
    cursor = conn.cursor()
    
    try:
        # Önce bu rotaya atanmış kargoların route_vehicle_id'sini NULL yap
        cursor.execute("""
            UPDATE cargos 
            SET route_vehicle_id = NULL, status = 'pending'
            WHERE route_vehicle_id IN (
                SELECT id FROM route_vehicles WHERE calculation_id = %s
            )
        """, (route_id,))
        
        # Araçları sil
        cursor.execute("DELETE FROM route_vehicles WHERE calculation_id = %s", (route_id,))
        
        # Hesaplamayı sil
        cursor.execute("DELETE FROM route_calculations WHERE id = %s", (route_id,))
        
        conn.commit()
        return jsonify({'success': True, 'message': 'Rota silindi'})
        
    except Exception as e:
        conn.rollback()
        print(f"Rota silme hatası: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        cursor.close()
        conn.close()


# ==================== DETAY API ====================

@app.route('/api/vehicle-details/<int:vehicle_id>')
@admin_required
def get_vehicle_details(vehicle_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Son hesaplamayı bul
    cursor.execute("SELECT MAX(id) as calc_id FROM route_calculations")
    calc_res = cursor.fetchone()
    if not calc_res['calc_id']: return jsonify({'error': 'Hesaplama yok'}), 404

    # Aracı bul
    cursor.execute("""
        SELECT * FROM route_vehicles 
        WHERE calculation_id = %s AND vehicle_id = %s
    """, (calc_res['calc_id'], vehicle_id))
    vehicle = cursor.fetchone()

    if not vehicle: return jsonify({'error': 'Araç bulunamadı'}), 404

    # Bu araca atanmış kargoları çek (Users tablosuyla join)
    cursor.execute("""
        SELECT c.weight, c.description, u.username, s.name as station_name
        FROM cargos c
        JOIN users u ON c.user_id = u.id
        JOIN stations s ON c.station_id = s.id
        WHERE c.route_vehicle_id = %s
    """, (vehicle['id'],))

    assigned_cargos = []
    for row in cursor.fetchall():
        assigned_cargos.append({
            'username': row['username'],
            'station': row['station_name'],
            'weight': row['weight'],
            'description': row['description']
        })

    conn.close()

    return jsonify({
        'vehicle_id': vehicle['vehicle_id'],
        'type': vehicle['vehicle_type'],
        'capacity': vehicle['capacity'],
        'load': vehicle['current_load'],
        'distance_km': vehicle['distance_km'],
        'cost': vehicle['cost'],
        'route': json.loads(vehicle['route_stations_json']),
        'path_coords': json.loads(vehicle['path_coords_json']) if vehicle['path_coords_json'] else [],
        'assigned_cargos': assigned_cargos
    })


@app.route('/api/cargo/<int:cargo_id>/route')
@login_required
def get_cargo_route(cargo_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    query = """
        SELECT c.*, s.name as station_name, rv.vehicle_id as v_int_id, 
               rv.vehicle_type, rv.route_stations_json, rv.path_coords_json,
               rv.distance_km, rv.capacity, rv.current_load
        FROM cargos c
        JOIN stations s ON c.station_id = s.id
        LEFT JOIN route_vehicles rv ON c.route_vehicle_id = rv.id
        WHERE c.id = %s
    """
    cursor.execute(query, (cargo_id,))
    cargo = cursor.fetchone()
    conn.close()

    if not cargo: return jsonify({'error': 'Kargo bulunamadı'}), 404
    if cargo['user_id'] != session['user_id'] and session.get('role') != 'admin':
        return jsonify({'error': 'Yetkisiz'}), 403

    if not cargo['route_vehicle_id']:
        return jsonify({
            'cargo_id': cargo_id,
            'station_name': cargo['station_name'],
            'status': cargo['status'],
            'message': 'Rota henüz planlanmadı'
        })

    return jsonify({
        'cargo_id': cargo_id,
        'station_name': cargo['station_name'],
        'vehicle_id': cargo['v_int_id'],
        'vehicle_info': f"Araç {cargo['v_int_id']} ({cargo['vehicle_type']})",
        'vehicle_capacity': cargo['capacity'],
        'vehicle_load': cargo['current_load'],
        'distance_km': cargo['distance_km'],
        'route': json.loads(cargo['route_stations_json']),
        'path_coords': json.loads(cargo['path_coords_json']),
        'status': cargo['status']
    })


if __name__ == '__main__':
    app.run(debug=True)