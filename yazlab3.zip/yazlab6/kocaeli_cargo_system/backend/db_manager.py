import mysql.connector
from mysql.connector import Error


class DBManager:
    def __init__(self):
        self.db_config = {
            'host': 'localhost',
            'user': 'root',  # MySQL kullanıcı adınız
            'password': '',  # MySQL şifreniz (varsa yazın)
            'database': 'kocaeli_kargo'
        }

    def get_connection(self):
        try:
            return mysql.connector.connect(**self.db_config)
        except Error as e:
            print(f"Veritabanı bağlantı hatası: {e}")
            return None

    # --- KULLANICI İŞLEMLERİ ---
    def get_user_by_username(self, username):
        conn = self.get_connection()
        if not conn: return None
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        return user

    def create_user(self, username, password, email, role='user'):
        conn = self.get_connection()
        if not conn: return False
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO users (username, password_hash, email, role) 
                VALUES (%s, %s, %s, %s)
            """, (username, password, email, role))
            conn.commit()
            return True
        except Error as e:
            print(f"Kayıt hatası: {e}")
            return False
        finally:
            conn.close()

    # --- İSTASYON İŞLEMLERİ ---
    def get_all_stations(self):
        conn = self.get_connection()
        if not conn: return []
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM stations ORDER BY name")
        stations = cursor.fetchall()
        conn.close()
        return stations

    # --- KARGO İŞLEMLERİ (Senin istediğin kısım) ---
    def add_cargo(self, username, station_id, weight, description):
        conn = self.get_connection()
        if not conn: return False
        try:
            # Önce username'den user_id bul
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
            res = cursor.fetchone()
            if not res: return False
            user_id = res[0]

            cursor.execute("""
                INSERT INTO cargos (user_id, station_id, weight, description, status, created_at) 
                VALUES (%s, %s, %s, %s, 'pending', NOW())
            """, (user_id, station_id, weight, description))
            conn.commit()
            return True
        except Error as e:
            print(f"Kargo ekleme hatası: {e}")
            return False
        finally:
            conn.close()

    def get_pending_cargos_summary(self):
        """
        Admin paneli için istasyon bazlı toplam bekleyen yükleri çeker.
        Dönüş: { 'Izmit': {'total_weight': 150, 'count': 3}, ... }
        """
        conn = self.get_connection()
        if not conn: return {}

        cursor = conn.cursor(dictionary=True)
        # Sadece 'pending' (bekleyen) kargoları topla
        query = """
            SELECT s.name as station_name, 
                   SUM(c.weight) as total_weight, 
                   COUNT(c.id) as cargo_count
            FROM cargos c
            JOIN stations s ON c.station_id = s.id
            WHERE c.status = 'pending'
            GROUP BY s.name
        """
        cursor.execute(query)
        results = cursor.fetchall()
        conn.close()

        # Sözlük formatına çevir ki HTML'de kolay kullanalım
        summary = {}
        for row in results:
            summary[row['station_name']] = {
                'weight': row['total_weight'],
                'count': row['cargo_count']
            }
        return summary