import math
from models import Vehicle

class RouteAlgorithm:
    def __init__(self, osm_helper, depot_station):
        self.osm = osm_helper
        self.depot = depot_station # Kocaeli Üni.
        # Mesafe Matrisi (Cache) - (id_from, id_to): km
        self.distance_matrix = {} 

    def get_distance(self, station_a, station_b):
        """İki istasyon arası mesafeyi getir (Cache'den veya hesapla)"""
        key = tuple(sorted((station_a.id, station_b.id)))
        if key in self.distance_matrix:
            return self.distance_matrix[key]
        
        # OSM üzerinden hesapla
        node_a = self.osm.get_nearest_node(station_a.lat, station_a.lon)
        node_b = self.osm.get_nearest_node(station_b.lat, station_b.lon)
        
        # Manuel Dijkstra ile mesafe (Metre -> KM)
        dist_m = self.osm.manual_dijkstra(node_a, node_b)
        dist_km = dist_m / 1000.0
        
        self.distance_matrix[key] = dist_km
        return dist_km

    def solve_nearest_neighbor(self, vehicle, stations_to_visit):
        """
        Gezgin Satıcı Problemi (TSP) için En Yakın Komşu (Nearest Neighbor) Sezgisel Algoritması.
        Başlangıç: Depot
        Adım: Bulunduğun yere en yakın, henüz gidilmemiş istasyona git.
        Bitiş: Depot'a dön.
        """
        current_station = self.depot
        route = [self.depot]
        unvisited = stations_to_visit.copy()
        total_distance = 0

        while unvisited:
            nearest_station = None
            min_dist = float('inf')

            for station in unvisited:
                dist = self.get_distance(current_station, station)
                if dist < min_dist:
                    min_dist = dist
                    nearest_station = station
            
            if nearest_station:
                current_station = nearest_station
                unvisited.remove(nearest_station)
                route.append(nearest_station)
                total_distance += min_dist
        
        # Dönüş yolu
        return_dist = self.get_distance(current_station, self.depot)
        route.append(self.depot)
        total_distance += return_dist
        
        vehicle.route = route
        vehicle.total_km = total_distance
        return vehicle

    def distribute_cargo_scenario_b(self, all_stations):
        """
        Senaryo B: Sınırsız Araç Problemi
        Strateji:
        1. Mevcut araçları (1000, 750, 500) doldur.
        2. Kalan yükler için kiralık araç (500) ekle.
        3. Rotaları optimize et.
        """
        # İstasyonları yük miktarına göre sırala (Büyükten küçüğe - Greedy)
        sorted_stations = sorted(all_stations, key=lambda x: x.cargo_weight, reverse=True)
        
        vehicles = [
            Vehicle(1, 1000, 'ozmal'),
            Vehicle(2, 750, 'ozmal'),
            Vehicle(3, 500, 'ozmal')
        ]
        
        rented_vehicle_count = 0
        active_vehicles = []

        # Basit Bin Packing (Kutulama) Mantığı
        for station in sorted_stations:
            assigned = False
            # Önce mevcut araçlara sığdırmaya çalış
            for v in vehicles:
                if v.load_cargo(station.cargo_weight):
                    # Bu araca bu istasyonu ekle (şimdilik sadece yük olarak, rota sonra)
                    if not hasattr(v, 'assigned_stations'): v.assigned_stations = []
                    v.assigned_stations.append(station)
                    assigned = True
                    if v not in active_vehicles:
                        active_vehicles.append(v)
                    break
            
            # Sığmadıysa yeni araç kirala
            if not assigned:
                rented_vehicle_count += 1
                new_v = Vehicle(100 + rented_vehicle_count, 500, 'kiralik')
                new_v.load_cargo(station.cargo_weight) # Tek seferde sığmıyorsa bölme mantığı eklenebilir
                new_v.assigned_stations = [station]
                active_vehicles.append(new_v)

        # Her araç için rota çiz
        for v in active_vehicles:
            self.solve_nearest_neighbor(v, v.assigned_stations)

        return active_vehicles

    def distribute_cargo_scenario_c(self, all_stations):
        """
        Senaryo C: Belirli Sayıda Araç (Sadece 3 Araç)
        Strateji: Kapasiteyi aşmadan maksimum yükü taşı veya maliyeti minimize et.
        """
        vehicles = [
            Vehicle(1, 1000, 'ozmal'),
            Vehicle(2, 750, 'ozmal'),
            Vehicle(3, 500, 'ozmal')
        ]
        
        # Yükleri küçükten büyüğe sırala ki daha fazla istasyona uğrayabilelim (veya tam tersi strateji)
        # Burada "Maksimum Verim" dediği için en ağır yükleri önceliklendirelim.
        sorted_stations = sorted(all_stations, key=lambda x: x.cargo_weight, reverse=True)
        
        active_vehicles = []
        
        for station in sorted_stations:
            for v in vehicles:
                if v.load_cargo(station.cargo_weight):
                    if not hasattr(v, 'assigned_stations'): v.assigned_stations = []
                    v.assigned_stations.append(station)
                    if v not in active_vehicles:
                        active_vehicles.append(v)
                    break
            # Sığmayan yükler dışarıda kalır (Senaryo C kısıtı)

        for v in active_vehicles:
            self.solve_nearest_neighbor(v, v.assigned_stations)
            
        return active_vehicles
