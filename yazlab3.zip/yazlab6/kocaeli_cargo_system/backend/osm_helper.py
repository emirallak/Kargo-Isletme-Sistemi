import heapq
import pickle
import os
import json
import requests
import math

# osmnx opsiyonel - yüklü değilse OSRM kullanılır
try:
    import osmnx as ox
    import networkx as nx
    OSMNX_AVAILABLE = True
except ImportError:
    OSMNX_AVAILABLE = False
    print("ℹ️ osmnx yüklü değil, sadece OSRM API kullanılacak")

class OSMHelper:
    """
    OpenStreetMap Helper - Kocaeli Yol Ağı Yönetimi
    
    ÖNCELIK SIRASI:
    1. OSRM API (Google Maps benzeri gerçek sokak rotası) - ÖNCELİKLİ
    2. Manuel Dijkstra (OSM graph üzerinde) - FALLBACK
    3. Haversine (düz çizgi) - SON ÇARE
    """
    
    CACHE_DIR = os.path.join(os.path.dirname(__file__), '..', 'cache')
    GRAPH_CACHE_FILE = os.path.join(CACHE_DIR, 'kocaeli_graph.pkl')
    DISTANCE_CACHE_FILE = os.path.join(CACHE_DIR, 'distance_cache.json')
    ROUTE_CACHE_FILE = os.path.join(CACHE_DIR, 'route_cache.json')
    
    # OSRM API (Ücretsiz, açık kaynak - Google Maps benzeri routing)
    OSRM_API_URL = "http://router.project-osrm.org/route/v1/driving"
    
    def __init__(self, place_name="Kocaeli, Turkey"):
        self.place_name = place_name
        self.G = None
        self.distance_cache = {}
        self.route_cache = {}
        self.path_cache = {}
        
        # Cache klasörünü oluştur
        os.makedirs(self.CACHE_DIR, exist_ok=True)
        
        # osmnx varsa graph'ı yükle
        if OSMNX_AVAILABLE:
            self._load_or_download_graph()
        
        # Cache'leri yükle
        self._load_distance_cache()
        self._load_route_cache()
    
    def _load_or_download_graph(self):
        """Graph'ı cache'den yükle veya OSM'den indir"""
        if os.path.exists(self.GRAPH_CACHE_FILE):
            print("📍 Harita cache'den yükleniyor...")
            try:
                with open(self.GRAPH_CACHE_FILE, 'rb') as f:
                    self.G = pickle.load(f)
                print(f"✅ Harita yüklendi! ({self.G.number_of_nodes()} düğüm, {self.G.number_of_edges()} kenar)")
                return
            except Exception as e:
                print(f"⚠️ Cache yüklenemedi: {e}")
        
        print(f"🌍 Harita indiriliyor: {self.place_name}...")
        print("⏳ Bu işlem ilk seferde 2-5 dakika sürebilir...")
        
        # OSMnx ayarları
        ox.settings.use_cache = True
        ox.settings.log_console = True
        
        # Sadece araç yollarını indir
        self.G = ox.graph_from_place(self.place_name, network_type='drive')
        
        # Graph'ı cache'e kaydet
        print("💾 Harita cache'e kaydediliyor...")
        with open(self.GRAPH_CACHE_FILE, 'wb') as f:
            pickle.dump(self.G, f)
        
        print(f"✅ Harita hazır! ({self.G.number_of_nodes()} düğüm, {self.G.number_of_edges()} kenar)")
    
    def _load_distance_cache(self):
        """Önceden hesaplanmış mesafeleri yükle"""
        if os.path.exists(self.DISTANCE_CACHE_FILE):
            try:
                with open(self.DISTANCE_CACHE_FILE, 'r') as f:
                    self.distance_cache = json.load(f)
                print(f"📊 {len(self.distance_cache)} mesafe cache'den yüklendi")
            except:
                self.distance_cache = {}
    
    def _load_route_cache(self):
        """OSRM rota cache'ini yükle"""
        if os.path.exists(self.ROUTE_CACHE_FILE):
            try:
                with open(self.ROUTE_CACHE_FILE, 'r') as f:
                    self.route_cache = json.load(f)
                print(f"🛣️ {len(self.route_cache)} rota cache'den yüklendi")
            except:
                self.route_cache = {}
    
    def _save_distance_cache(self):
        """Hesaplanan mesafeleri kaydet"""
        with open(self.DISTANCE_CACHE_FILE, 'w') as f:
            json.dump(self.distance_cache, f)
    
    def _save_route_cache(self):
        """OSRM rotalarını kaydet"""
        with open(self.ROUTE_CACHE_FILE, 'w') as f:
            json.dump(self.route_cache, f)
    
    def get_nearest_node(self, lat, lon):
        """Verilen koordinata en yakın yol düğümünü bulur"""
        return ox.distance.nearest_nodes(self.G, lon, lat)
    
    def get_osrm_route(self, coords_list):
        """
        OSRM API ile Google Maps benzeri gerçek sokak rotası al.
        
        coords_list: [(lat1, lon1), (lat2, lon2), ...] şeklinde koordinat listesi
        
        Returns: {
            'distance': toplam mesafe (km),
            'duration': toplam süre (dakika),
            'geometry': [[lat, lon], ...] detaylı yol koordinatları
        }
        """
        if len(coords_list) < 2:
            return None
        
        # Cache kontrolü
        cache_key = ";".join([f"{lat:.4f},{lon:.4f}" for lat, lon in coords_list])
        if cache_key in self.route_cache:
            return self.route_cache[cache_key]
        
        # OSRM API formatı: lon,lat (ters sıra!)
        coords_str = ";".join([f"{lon},{lat}" for lat, lon in coords_list])
        
        url = f"{self.OSRM_API_URL}/{coords_str}"
        params = {
            'overview': 'full',        # Tam geometri
            'geometries': 'geojson',   # GeoJSON formatında
            'steps': 'true',           # Adım adım talimatlar
            'annotations': 'true'      # Detaylı bilgi
        }
        
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            
            if data.get('code') != 'Ok':
                print(f"⚠️ OSRM hatası: {data.get('message', 'Bilinmeyen hata')}")
                return None
            
            route = data['routes'][0]
            
            # GeoJSON koordinatlarını [lat, lon] formatına çevir
            geojson_coords = route['geometry']['coordinates']
            path_coords = [[coord[1], coord[0]] for coord in geojson_coords]
            
            result = {
                'distance': round(route['distance'] / 1000, 2),  # metre -> km
                'duration': round(route['duration'] / 60, 1),    # saniye -> dakika
                'geometry': path_coords
            }
            
            # Cache'e kaydet
            self.route_cache[cache_key] = result
            self._save_route_cache()
            
            return result
            
        except requests.exceptions.RequestException as e:
            print(f"⚠️ OSRM API bağlantı hatası: {e}")
            return None
        except Exception as e:
            print(f"⚠️ OSRM işlem hatası: {e}")
            return None
    
    def manual_dijkstra(self, start_node, end_node):
        """
        MANUEL DIJKSTRA ALGORİTMASI
        Hazır shortest_path fonksiyonu yerine elle yazılmış implementasyon.
        
        Algoritma:
        1. Başlangıç düğümünden başla, mesafe = 0
        2. Priority queue kullanarak en yakın ziyaret edilmemiş düğümü seç
        3. Komşularının mesafelerini güncelle
        4. Hedef düğüme ulaşana kadar devam et
        
        Returns: (mesafe_metre, yol_listesi)
        """
        if start_node == end_node:
            return 0, [start_node]
        
        # Priority Queue: (mesafe, node_id, path)
        pq = [(0, start_node, [start_node])]
        distances = {start_node: 0}
        visited = set()
        
        while pq:
            current_dist, current_node, path = heapq.heappop(pq)
            
            if current_node in visited:
                continue
            visited.add(current_node)
            
            # Hedefe ulaştık
            if current_node == end_node:
                return current_dist, path
            
            # Komşuları gez
            for neighbor in self.G.neighbors(current_node):
                if neighbor in visited:
                    continue
                
                # Edge uzunluğunu al
                edge_data = self.G.get_edge_data(current_node, neighbor)
                weight = edge_data[0].get('length', 100)  # Metre cinsinden
                
                new_distance = current_dist + weight
                
                if neighbor not in distances or new_distance < distances[neighbor]:
                    distances[neighbor] = new_distance
                    new_path = path + [neighbor]
                    heapq.heappush(pq, (new_distance, neighbor, new_path))
        
        return float('inf'), []  # Yol bulunamadı
    
    def get_distance_and_path(self, lat1, lon1, lat2, lon2):
        """
        İki koordinat arası mesafe ve yol
        Returns: (mesafe_km, yol_koordinatlari)
        """
        # Cache anahtarı
        cache_key = f"{lat1:.4f},{lon1:.4f}-{lat2:.4f},{lon2:.4f}"
        
        if cache_key in self.distance_cache:
            cached = self.distance_cache[cache_key]
            return cached['distance'], cached.get('path', [])
        
        # En yakın düğümleri bul
        node1 = self.get_nearest_node(lat1, lon1)
        node2 = self.get_nearest_node(lat2, lon2)
        
        # Manuel Dijkstra ile hesapla
        distance_m, node_path = self.manual_dijkstra(node1, node2)
        distance_km = distance_m / 1000.0
        
        # Düğüm koordinatlarını al
        path_coords = []
        for node in node_path:
            node_data = self.G.nodes[node]
            path_coords.append([node_data['y'], node_data['x']])  # [lat, lon]
        
        # Cache'e kaydet
        self.distance_cache[cache_key] = {
            'distance': round(distance_km, 2),
            'path': path_coords
        }
        self._save_distance_cache()
        
        return round(distance_km, 2), path_coords
    
    def get_full_route_path(self, station_coords_list):
        """
        Birden fazla istasyon için tam rota koordinatları.
        
        ÖNCELİK SIRASI:
        1. OSRM API (Google Maps benzeri detaylı sokak rotası)
        2. Manuel Dijkstra (OSM graph üzerinde - fallback)
        
        station_coords_list: [(lat1, lon1), (lat2, lon2), ...]
        Returns: (toplam_mesafe_km, tüm_yol_koordinatları)
        """
        if len(station_coords_list) < 2:
            return 0, []
        
        # ÖNCE OSRM API'yi dene (Google Maps benzeri detaylı rota)
        osrm_result = self.get_osrm_route(station_coords_list)
        
        if osrm_result and osrm_result.get('geometry'):
            print(f"✅ OSRM: {osrm_result['distance']} km, {len(osrm_result['geometry'])} nokta")
            return osrm_result['distance'], osrm_result['geometry']
        
        # OSRM başarısız olursa Manuel Dijkstra kullan
        print("⚠️ OSRM başarısız, Manuel Dijkstra kullanılıyor...")
        return self._dijkstra_full_route(station_coords_list)
    
    def _dijkstra_full_route(self, station_coords_list):
        """Manuel Dijkstra ile rota hesapla (fallback)"""
        if len(station_coords_list) < 2:
            return 0, []
        
        total_distance = 0
        full_path = []
        
        for i in range(len(station_coords_list) - 1):
            lat1, lon1 = station_coords_list[i]
            lat2, lon2 = station_coords_list[i + 1]
            
            dist, path = self.get_distance_and_path(lat1, lon1, lat2, lon2)
            total_distance += dist
            
            # İlk segment hariç, başlangıç noktasını atla (tekrar olmasın)
            if i == 0:
                full_path.extend(path)
            else:
                full_path.extend(path[1:])
        
        return round(total_distance, 2), full_path
    
    def get_detailed_route(self, station_coords_list):
        """
        Detaylı rota bilgisi döndür (mesafe, süre, geometri, adımlar).
        
        Returns: {
            'total_distance_km': float,
            'total_duration_min': float,
            'path_coords': [[lat, lon], ...],
            'segments': [
                {'from': (lat, lon), 'to': (lat, lon), 'distance': float, 'duration': float},
                ...
            ]
        }
        """
        result = {
            'total_distance_km': 0,
            'total_duration_min': 0,
            'path_coords': [],
            'segments': []
        }
        
        if len(station_coords_list) < 2:
            return result
        
        # OSRM ile tam rota
        osrm_result = self.get_osrm_route(station_coords_list)
        
        if osrm_result:
            result['total_distance_km'] = osrm_result['distance']
            result['total_duration_min'] = osrm_result['duration']
            result['path_coords'] = osrm_result['geometry']
            
            # Her segment için bilgi ekle
            for i in range(len(station_coords_list) - 1):
                segment_result = self.get_osrm_route([
                    station_coords_list[i],
                    station_coords_list[i + 1]
                ])
                if segment_result:
                    result['segments'].append({
                        'from': station_coords_list[i],
                        'to': station_coords_list[i + 1],
                        'distance': segment_result['distance'],
                        'duration': segment_result['duration']
                    })
        else:
            # Fallback
            dist, path = self._dijkstra_full_route(station_coords_list)
            result['total_distance_km'] = dist
            result['path_coords'] = path
        
        return result
    
    def clear_cache(self):
        """Tüm cache'i temizle"""
        self.distance_cache = {}
        self.route_cache = {}
        if os.path.exists(self.DISTANCE_CACHE_FILE):
            os.remove(self.DISTANCE_CACHE_FILE)
        if os.path.exists(self.ROUTE_CACHE_FILE):
            os.remove(self.ROUTE_CACHE_FILE)
        print("🗑️ Cache temizlendi")


# Test fonksiyonu
if __name__ == "__main__":
    print("=" * 60)
    print("OSM Helper Test - OSRM API ile Gerçek Sokak Rotası")
    print("=" * 60)
    
    # Helper'ı başlat
    osm = OSMHelper("Kocaeli, Turkey")
    
    # Test: Gebze -> İzmit (OSRM ile)
    print("\n📍 Test 1: Gebze -> İzmit (OSRM API)")
    coords = [(40.802, 29.430), (40.766, 29.940)]
    osrm_result = osm.get_osrm_route(coords)
    if osrm_result:
        print(f"   ✅ Mesafe: {osrm_result['distance']} km")
        print(f"   ⏱️ Süre: {osrm_result['duration']} dakika")
        print(f"   📍 Yol noktası: {len(osrm_result['geometry'])} nokta")
    
    # Test: Tam Rota (Darıca -> Gebze -> İzmit -> Umuttepe)
    print("\n📍 Test 2: Darıca -> Gebze -> İzmit -> Umuttepe (Tam Rota)")
    stations = [
        (40.773, 29.400),  # Darıca (başlangıç - en uzak)
        (40.802, 29.430),  # Gebze
        (40.766, 29.940),  # İzmit
        (40.822, 29.922),  # Umuttepe (bitiş)
    ]
    total_dist, full_path = osm.get_full_route_path(stations)
    print(f"   ✅ Toplam Mesafe: {total_dist} km")
    print(f"   📍 Toplam Yol Noktası: {len(full_path)}")
    if full_path:
        print(f"   🚗 İlk 3 koordinat: {full_path[:3]}")
        print(f"   🏁 Son 3 koordinat: {full_path[-3:]}")
