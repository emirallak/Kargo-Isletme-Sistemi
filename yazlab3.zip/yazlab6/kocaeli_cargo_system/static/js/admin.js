// Admin Panel JavaScript - Temizlenmiş Versiyon

document.addEventListener('DOMContentLoaded', function() {
    // Tab Navigation
    const menuItems = document.querySelectorAll('.sidebar-menu li');
    const tabContents = document.querySelectorAll('.tab-content');
    const pageTitle = document.getElementById('page-title');

    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            const tabId = this.dataset.tab;
            
            menuItems.forEach(i => i.classList.remove('active'));
            tabContents.forEach(t => t.classList.remove('active'));
            
            this.classList.add('active');
            document.getElementById(tabId).classList.add('active');
            pageTitle.textContent = this.textContent.trim();
            
            if (tabId === 'dashboard') {
                initDashboardMap();
            } else if (tabId === 'routes-view') {
                initRoutesMap();
                loadSavedRoutes();
            }
        });
    });

    initDashboardMap();

    // Preset Scenarios
    const scenarios = {
        '1': [
            {station: 'Basiskele', weight: 120, count: 10},
            {station: 'Cayirova', weight: 80, count: 8},
            {station: 'Darica', weight: 200, count: 15},
            {station: 'Derince', weight: 150, count: 10},
            {station: 'Dilovasi', weight: 180, count: 12},
            {station: 'Gebze', weight: 70, count: 5},
            {station: 'Golcuk', weight: 90, count: 7},
            {station: 'Kandira', weight: 60, count: 6},
            {station: 'Karamursel', weight: 110, count: 9},
            {station: 'Kartepe', weight: 130, count: 11},
            {station: 'Korfez', weight: 75, count: 6},
            {station: 'Izmit', weight: 160, count: 14}
        ],
        '2': [
            {station: 'Basiskele', weight: 200, count: 40},
            {station: 'Cayirova', weight: 175, count: 35},
            {station: 'Darica', weight: 150, count: 10},
            {station: 'Derince', weight: 100, count: 5},
            {station: 'Gebze', weight: 120, count: 8},
            {station: 'Izmit', weight: 160, count: 20}
        ],
        '3': [
            {station: 'Cayirova', weight: 700, count: 3},
            {station: 'Dilovasi', weight: 800, count: 4},
            {station: 'Gebze', weight: 900, count: 5},
            {station: 'Izmit', weight: 300, count: 5}
        ],
        '4': [
            {station: 'Basiskele', weight: 300, count: 30},
            {station: 'Golcuk', weight: 220, count: 15},
            {station: 'Kandira', weight: 250, count: 5},
            {station: 'Karamursel', weight: 180, count: 20},
            {station: 'Kartepe', weight: 200, count: 10},
            {station: 'Korfez', weight: 400, count: 8}
        ]
    };

    document.getElementById('preset-scenario').addEventListener('change', function() {
        const scenarioId = this.value;
        if (!scenarioId) return;

        const data = scenarios[scenarioId];
        document.querySelectorAll('.cargo-weight').forEach(input => input.value = 0);
        document.querySelectorAll('.cargo-count').forEach(input => input.value = 0);

        data.forEach(item => {
            document.querySelectorAll('#stations-table tr').forEach(row => {
                if (row.cells[1]?.textContent === item.station) {
                    row.querySelector('.cargo-weight').value = item.weight;
                    row.querySelector('.cargo-count').value = item.count;
                }
            });
        });
        updateTotalCargo();
    });

    document.getElementById('calculate-routes').addEventListener('click', calculateRoutes);

    document.getElementById('add-station-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('/api/stations', {
            method: 'POST',
            body: JSON.stringify({
                name: formData.get('name'),
                lat: parseFloat(formData.get('lat')),
                lon: parseFloat(formData.get('lon'))
            }),
            headers: {'Content-Type': 'application/json'}
        }).then(res => res.json()).then(data => {
            if (data.success) location.reload();
            else alert('Hata: ' + data.error);
        });
    });

    document.querySelectorAll('.cargo-weight').forEach(input => {
        input.addEventListener('change', updateTotalCargo);
    });

    // Sayfa yüklendiğinde toplam kargo değerini hesapla
    updateTotalCargo();
});

const stationCoords = {
    'Umuttepe': [40.822, 29.922],
    'Basiskele': [40.715, 29.928],
    'Cayirova': [40.815, 29.375],
    'Darica': [40.773, 29.400],
    'Derince': [40.756, 29.830],
    'Dilovasi': [40.787, 29.544],
    'Gebze': [40.802, 29.430],
    'Golcuk': [40.717, 29.820],
    'Kandira': [41.070, 30.150],
    'Karamursel': [40.692, 29.615],
    'Kartepe': [40.753, 30.020],
    'Korfez': [40.765, 29.780],
    'Izmit': [40.766, 29.940]
};

let dashboardMap = null;
let routesMap = null;
let routeAnimationLayers = [];
let isLoadingRoutes = false; // Sonsuz döngüyü önlemek için flag

function initDashboardMap() {
    if (dashboardMap) { dashboardMap.invalidateSize(); return; }
    dashboardMap = L.map('dashboard-map').setView([40.78, 29.75], 10);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap', maxZoom: 19
    }).addTo(dashboardMap);

    for (const [name, coords] of Object.entries(stationCoords)) {
        const color = name === 'Umuttepe' ? 'red' : 'blue';
        L.marker(coords, {
            icon: L.divIcon({
                html: `<div style="background:${color};width:12px;height:12px;border-radius:50%;border:2px solid white;"></div>`,
                iconSize: [12, 12]
            })
        }).addTo(dashboardMap).bindPopup(`<b>${name}</b>${name === 'Umuttepe' ? '<br>(Merkez)' : ''}`);
    }
}

function initRoutesMap() {
    // Harita zaten varsa sadece boyutunu güncelle
    if (routesMap) { 
        setTimeout(() => routesMap.invalidateSize(), 100);
        return; 
    }
    
    const mapContainer = document.getElementById('routes-map');
    if (!mapContainer) return;
    
    routesMap = L.map('routes-map').setView([40.78, 29.75], 10);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap'
    }).addTo(routesMap);
}

function updateTotalCargo() {
    let totalWeight = 0, totalCount = 0, activeStations = 0;
    document.querySelectorAll('#stations-table tr').forEach(row => {
        const weight = parseInt(row.querySelector('.cargo-weight')?.value) || 0;
        const count = parseInt(row.querySelector('.cargo-count')?.value) || 0;
        totalWeight += weight;
        totalCount += count;
        if (weight > 0) activeStations++;
    });
    document.getElementById('total-cargo').textContent = totalWeight;
    if (document.getElementById('summary-weight')) document.getElementById('summary-weight').textContent = totalWeight;
    if (document.getElementById('summary-count')) document.getElementById('summary-count').textContent = totalCount;
    if (document.getElementById('summary-stations')) document.getElementById('summary-stations').textContent = activeStations;
}

function calculateRoutes() {
    const scenarioType = document.getElementById('scenario-type').value;
    const cargos = [];

    document.querySelectorAll('#stations-table tr').forEach(row => {
        const stationName = row.cells[1]?.textContent;
        const weight = parseInt(row.querySelector('.cargo-weight')?.value) || 0;
        const count = parseInt(row.querySelector('.cargo-count')?.value) || 0;
        if (weight > 0) cargos.push({ station_name: stationName, weight, count });
    });

    if (cargos.length === 0) { alert('Lütfen en az bir istasyona kargo ekleyin!'); return; }

    const calcBtn = document.getElementById('calculate-routes');
    const originalText = calcBtn.innerHTML;
    calcBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Hesaplanıyor...';
    calcBtn.disabled = true;

    fetch('/api/solve', {
        method: 'POST',
        body: JSON.stringify({ scenario: scenarioType, optimization: 'cost', cargos }),
        headers: {'Content-Type': 'application/json'}
    })
    .then(res => res.json())
    .then(data => {
        calcBtn.innerHTML = originalText;
        calcBtn.disabled = false;
        if (data.error) { alert('Hata: ' + data.error); return; }
        
        displayBothResults(data, scenarioType);
        
        // Seçilen senaryoya göre haritada göster
        let vehiclesToShow;
        if (scenarioType === 'limited') {
            vehiclesToShow = data.limited?.vehicles || data.vehicles;
        } else if (scenarioType === 'unlimited') {
            vehiclesToShow = data.unlimited?.vehicles || data.vehicles;
        } else {
            // both - en iyi senaryoyu göster
            vehiclesToShow = data.best_scenario?.vehicles || data.unlimited?.vehicles || data.vehicles;
        }
        
        if (vehiclesToShow) drawRealRoutesOnMap(vehiclesToShow);
    })
    .catch(err => {
        calcBtn.innerHTML = originalText;
        calcBtn.disabled = false;
        alert('Hata: ' + err.message);
    });
}

function displayBothResults(data, scenarioType) {
    const resultsDiv = document.getElementById('route-results');
    const unlimitedDiv = document.getElementById('unlimited-results');
    const limitedDiv = document.getElementById('limited-results');
    
    if (scenarioType === 'unlimited') {
        unlimitedDiv.classList.remove('d-none');
        limitedDiv.classList.add('d-none');
        displayUnlimitedResults(data.unlimited || data);
    } else if (scenarioType === 'limited') {
        unlimitedDiv.classList.add('d-none');
        limitedDiv.classList.remove('d-none');
        displayLimitedResults(data.limited || data);
    } else {
        unlimitedDiv.classList.remove('d-none');
        limitedDiv.classList.remove('d-none');
        if (data.unlimited) displayUnlimitedResults(data.unlimited);
        if (data.limited) displayLimitedResults(data.limited);
    }
    
    const cost = data.unlimited?.total_cost || data.limited?.total_cost || data.total_cost || 0;
    document.getElementById('result-total-cost').textContent = cost.toFixed(2);
    window.lastUnlimitedResult = data.unlimited;
    window.lastLimitedResult = data.limited;
    resultsDiv.classList.remove('d-none');
}

function displayUnlimitedResults(data) {
    const container = document.getElementById('unlimited-results-body');
    if (!container) return;
    
    const vehicleColors = ['#e74c3c', '#3498db', '#2ecc71', '#9b59b6', '#f39c12', '#1abc9c', '#e91e63', '#00bcd4', '#ff5722', '#673ab7'];
    const totalWeight = data.total_weight || 0;
    
    let html = `
        <div class="row mb-3">
            <div class="col-md-3"><div class="bg-light p-3 rounded text-center"><h3 class="text-success mb-0">${data.total_cost?.toFixed(2) || 0}</h3><small>Toplam Maliyet</small></div></div>
            <div class="col-md-3"><div class="bg-light p-3 rounded text-center"><h3 class="text-primary mb-0">${data.vehicles?.length || 0}</h3><small>Toplam Araç</small></div></div>
            <div class="col-md-3"><div class="bg-light p-3 rounded text-center"><h3 class="text-info mb-0">${totalWeight} kg</h3><small>Toplam Kargo</small></div></div>
            <div class="col-md-3"><div class="bg-light p-3 rounded text-center"><h3 class="text-warning mb-0">${data.rental_count || 0}</h3><small>Kiralık Araç</small></div></div>
        </div>
    `;
    
    if (data.all_scenarios?.length > 0) {
        html += `<h6><i class="fas fa-list"></i> Senaryolar:</h6><div class="table-responsive"><table class="table table-sm table-bordered"><thead class="table-light"><tr><th>Senaryo</th><th>Araç</th><th>Kiralık</th><th>Maliyet</th><th></th></tr></thead><tbody>`;
        [...data.all_scenarios].sort((a, b) => a.total_cost - b.total_cost).forEach((s, i) => {
            html += `<tr class="${i === 0 ? 'table-success' : ''}"><td>${s.name}</td><td>${s.vehicle_count}</td><td>${s.rental_count || 0}</td><td><strong>${s.total_cost.toFixed(2)}</strong></td><td>${i === 0 ? '⭐' : ''}</td></tr>`;
        });
        html += '</tbody></table></div>';
    }
    
    if (data.vehicles?.length > 0) {
        html += '<h6 class="mt-3"><i class="fas fa-truck"></i> Araç Detayları:</h6>';
        html += '<div class="route-optimization-results">';
        
        data.vehicles.forEach((v, idx) => {
            const color = vehicleColors[idx % vehicleColors.length];
            const capacityLeft = v.capacity - v.load;
            const routeStops = (v.route || []).filter(s => s !== 'Umuttepe');
            const isRental = v.type === 'kiralik';
            
            html += `
                <div class="card mb-2" style="border-left: 5px solid ${color};">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="mb-0" style="color:${color};">
                                <i class="fas fa-truck"></i> Araç ${v.vehicle_id} 
                                <span class="badge ${isRental ? 'bg-warning' : 'bg-success'}">${isRental ? '🔑 Kiralık' : '🚛 Özmal'}</span>
                            </h6>
                            <span class="badge bg-secondary">${v.capacity} kg kapasite</span>
                        </div>
                        <div class="row text-center mb-2">
                            <div class="col-4">
                                <div class="border rounded p-2">
                                    <div class="h5 mb-0 text-primary">${v.distance_km?.toFixed(2) || 0} km</div>
                                    <small class="text-muted">Mesafe</small>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="border rounded p-2">
                                    <div class="h5 mb-0 text-success">${v.load || 0} kg</div>
                                    <small class="text-muted">Taşınan</small>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="border rounded p-2">
                                    <div class="h5 mb-0 text-info">${capacityLeft} kg</div>
                                    <small class="text-muted">Kalan</small>
                                </div>
                            </div>
                        </div>
                        <div class="bg-light rounded p-2">
                            <small class="text-muted d-block mb-1"><i class="fas fa-route"></i> Rota (${routeStops.length} durak):</small>
                            <strong>${routeStops.map((s, i) => `<span style="color:${color}">${i+1}.</span> ${s}`).join(' → ') || 'Rota yok'}</strong>
                        </div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
    }
    container.innerHTML = html;
}

function displayLimitedResults(data) {
    const container = document.getElementById('limited-results-body');
    if (!container) return;
    
    const vehicleColors = ['#27ae60', '#2980b9', '#8e44ad'];
    const hasRejected = data.rejected_weight > 0;
    
    let html = `
        <div class="row mb-3">
            <div class="col-md-3"><div class="bg-light p-3 rounded text-center"><h3 class="text-success mb-0">${data.total_cost?.toFixed(2) || 0}</h3><small>Toplam Maliyet</small></div></div>
            <div class="col-md-3"><div class="bg-light p-3 rounded text-center"><h3 class="text-primary mb-0">${data.accepted_weight || 0} kg</h3><small>Kabul Edilen</small></div></div>
            <div class="col-md-3"><div class="bg-light p-3 rounded text-center ${hasRejected ? 'border border-danger' : ''}"><h3 class="${hasRejected ? 'text-danger' : 'text-success'} mb-0">${data.rejected_weight || 0} kg</h3><small>Reddedilen</small></div></div>
            <div class="col-md-3"><div class="bg-light p-3 rounded text-center"><h3 class="text-info mb-0">${data.accepted_count || 0}/${data.total_count || 0}</h3><small>Teslimat</small></div></div>
        </div>
    `;
    
    if (hasRejected && data.rejected_stations) {
        html += `<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <strong>Kapasite Yetersiz!</strong> Reddedilen istasyonlar: <strong>${data.rejected_stations.join(', ')}</strong></div>`;
    } else {
        html += `<div class="alert alert-success"><i class="fas fa-check-circle"></i> Tüm kargolar başarıyla kabul edildi!</div>`;
    }
    
    if (data.vehicles?.length > 0) {
        html += '<h6 class="mt-3"><i class="fas fa-truck"></i> Araç Detayları (3 Özmal Araç):</h6>';
        html += '<div class="route-optimization-results">';
        
        data.vehicles.forEach((v, idx) => {
            const color = vehicleColors[idx % vehicleColors.length];
            const capacityLeft = v.capacity - v.load;
            const pct = ((v.load / v.capacity) * 100).toFixed(0);
            const routeStops = (v.route || []).filter(s => s !== 'Umuttepe');
            
            html += `
                <div class="card mb-2" style="border-left: 5px solid ${color};">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="mb-0" style="color:${color};">
                                <i class="fas fa-truck"></i> Araç ${v.vehicle_id} 
                                <span class="badge bg-success">🚛 Özmal</span>
                            </h6>
                            <span class="badge bg-${pct > 80 ? 'warning' : 'success'}">${pct}% Dolu</span>
                        </div>
                        <div class="progress mb-2" style="height:8px;">
                            <div class="progress-bar" style="width:${pct}%;background:${color};"></div>
                        </div>
                        <div class="row text-center mb-2">
                            <div class="col-3">
                                <div class="border rounded p-2">
                                    <div class="h6 mb-0 text-primary">${v.distance_km?.toFixed(2) || 0} km</div>
                                    <small class="text-muted">Mesafe</small>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="border rounded p-2">
                                    <div class="h6 mb-0 text-success">${v.load || 0} kg</div>
                                    <small class="text-muted">Taşınan</small>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="border rounded p-2">
                                    <div class="h6 mb-0 text-info">${capacityLeft} kg</div>
                                    <small class="text-muted">Kalan</small>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="border rounded p-2">
                                    <div class="h6 mb-0 text-secondary">${v.capacity} kg</div>
                                    <small class="text-muted">Kapasite</small>
                                </div>
                            </div>
                        </div>
                        <div class="bg-light rounded p-2">
                            <small class="text-muted d-block mb-1"><i class="fas fa-route"></i> Rota (${routeStops.length} durak):</small>
                            <strong>${routeStops.map((s, i) => `<span style="color:${color}">${i+1}.</span> ${s}`).join(' → ') || 'Rota yok'}</strong>
                        </div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
    }
    container.innerHTML = html;
}

function showUnlimitedOnMap() {
    if (window.lastUnlimitedResult?.vehicles) drawRealRoutesOnMap(window.lastUnlimitedResult.vehicles);
}

function showLimitedOnMap() {
    if (window.lastLimitedResult?.vehicles) drawRealRoutesOnMap(window.lastLimitedResult.vehicles);
}

function drawRealRoutesOnMap(vehicles) {
    // Her araç için benzersiz ve belirgin renkler
    const vehicleColors = [
        '#e74c3c', // Kırmızı
        '#3498db', // Mavi
        '#2ecc71', // Yeşil
        '#9b59b6', // Mor
        '#f39c12', // Turuncu
        '#1abc9c', // Turkuaz
        '#e91e63', // Pembe
        '#00bcd4', // Açık Mavi
        '#ff5722', // Koyu Turuncu
        '#673ab7'  // Koyu Mor
    ];
    
    // Harita yoksa oluştur (sadece bir kez)
    const mapContainer = document.getElementById('routes-map');
    if (!mapContainer) return;
    
    if (!routesMap) {
        routesMap = L.map('routes-map').setView([40.78, 29.75], 11);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap | OSRM', maxZoom: 19
        }).addTo(routesMap);
    } else {
        // Harita zaten varsa sadece boyutunu güncelle
        setTimeout(() => routesMap.invalidateSize(), 100);
    }

    // Önceki katmanları temizle
    routeAnimationLayers.forEach(l => {
        try { routesMap.removeLayer(l); } catch(e) {}
    });
    routeAnimationLayers = [];
    
    // Diğer katmanları da temizle
    routesMap.eachLayer(layer => {
        if ((layer instanceof L.Polyline || layer instanceof L.CircleMarker || layer instanceof L.Marker) && !layer._url) {
            try { routesMap.removeLayer(layer); } catch(e) {}
        }
    });

    // Merkez marker
    const centerMarker = L.marker(stationCoords['Umuttepe'], {
        icon: L.divIcon({
            html: `<div style="background:#e74c3c;width:35px;height:35px;border-radius:50%;border:3px solid white;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,0.3);">🏁</div>`,
            iconSize: [35, 35], iconAnchor: [17, 17]
        })
    }).addTo(routesMap).bindPopup('<b>🏁 Umuttepe</b><br>Merkez Deposu');
    routeAnimationLayers.push(centerMarker);

    // Legend'ı güncelle
    const legend = document.querySelector('.legend-items');
    if (legend) {
        legend.innerHTML = `
            <div class="mb-3 p-2 bg-dark text-white rounded">
                <strong><i class="fas fa-truck"></i> Araç Renk Kodları</strong>
            </div>
        `;
    }

    // Aynı istasyona giden araçları takip et (marker offset için)
    const stationVehicleCount = {};
    vehicles.forEach(v => {
        (v.route || []).forEach(s => {
            if (s !== 'Umuttepe') {
                stationVehicleCount[s] = (stationVehicleCount[s] || 0) + 1;
            }
        });
    });
    
    // Her istasyonda kaçıncı araç olduğunu takip et
    const stationCurrentIndex = {};

    // Çizgileri offset ile ayırmak için yardımcı fonksiyon
    function offsetPath(path, offsetAmount) {
        if (!path || path.length < 2) return path;
        
        const offsetted = [];
        for (let i = 0; i < path.length; i++) {
            const lat = path[i][0];
            const lng = path[i][1];
            
            // Basit perpendicular offset
            let angle = 0;
            if (i < path.length - 1) {
                const nextLat = path[i + 1][0];
                const nextLng = path[i + 1][1];
                angle = Math.atan2(nextLng - lng, nextLat - lat) + Math.PI / 2;
            } else if (i > 0) {
                const prevLat = path[i - 1][0];
                const prevLng = path[i - 1][1];
                angle = Math.atan2(lng - prevLng, lat - prevLat) + Math.PI / 2;
            }
            
            offsetted.push([
                lat + Math.cos(angle) * offsetAmount,
                lng + Math.sin(angle) * offsetAmount
            ]);
        }
        return offsetted;
    }

    // Her araç için rota çiz
    vehicles.forEach((v, idx) => {
        const color = vehicleColors[idx % vehicleColors.length];
        const path = v.path_coords || [];
        const distance = v.distance_km || 0;
        const load = v.load || 0;
        const capacity = v.capacity || 750;
        const capacityLeft = capacity - load;
        const routeStops = (v.route || []).filter(s => s !== 'Umuttepe').length;
        const isRental = v.type === 'kiralik';
        
        // Her aracı farklı offset ile çiz (üst üste binmesin)
        const offsetAmount = (idx - (vehicles.length - 1) / 2) * 0.0008;
        const offsettedPath = offsetPath(path, offsetAmount);
        
        // Rota çiz
        if (offsettedPath.length > 0) {
            // Gölge
            routeAnimationLayers.push(L.polyline(offsettedPath, {
                color: '#000', 
                weight: 10, 
                opacity: 0.15
            }).addTo(routesMap));
            
            // Ana çizgi
            const line = L.polyline(offsettedPath, {
                color, 
                weight: 6, 
                opacity: 1.0
            }).addTo(routesMap);
            routeAnimationLayers.push(line);
            
            // Popup bilgisi
            line.bindPopup(`
                <div style="min-width: 180px;">
                    <h6 style="color:${color};margin-bottom:8px;">
                        <i class="fas fa-truck"></i> Araç ${v.vehicle_id} ${isRental ? '🔑' : '🚛'}
                    </h6>
                    <table class="table table-sm table-borderless mb-0">
                        <tr><td><i class="fas fa-road"></i> Mesafe:</td><td><strong>${distance.toFixed(2)} km</strong></td></tr>
                        <tr><td><i class="fas fa-box"></i> Taşınan:</td><td><strong>${load} kg</strong></td></tr>
                        <tr><td><i class="fas fa-battery-half"></i> Kalan:</td><td><strong>${capacityLeft} kg</strong></td></tr>
                        <tr><td><i class="fas fa-map-marker-alt"></i> Durak:</td><td><strong>${routeStops} adet</strong></td></tr>
                    </table>
                </div>
            `);
        } else {
            // OSRM yolu yoksa düz çizgi
            const coords = v.route.map(s => stationCoords[s]).filter(c => c);
            if (coords.length > 1) {
                const offsettedCoords = offsetPath(coords, offsetAmount);
                routeAnimationLayers.push(L.polyline(offsettedCoords, {
                    color, 
                    weight: 4, 
                    dashArray: '10,5'
                }).addTo(routesMap));
            }
        }

        // Durak noktaları işaretle
        v.route.forEach((s, i) => {
            if (s !== 'Umuttepe' && stationCoords[s]) {
                const stopNum = i + 1;
                
                // Bu istasyona kaçıncı araç geliyor?
                stationCurrentIndex[s] = (stationCurrentIndex[s] || 0) + 1;
                const vehicleIndexAtStation = stationCurrentIndex[s];
                const totalVehiclesAtStation = stationVehicleCount[s];
                
                // Aynı istasyona birden fazla araç geliyorsa marker'ları kaydır
                let offsetLat = 0;
                let offsetLng = 0;
                if (totalVehiclesAtStation > 1) {
                    // Daire şeklinde yerleştir
                    const angle = (2 * Math.PI * (vehicleIndexAtStation - 1)) / totalVehiclesAtStation;
                    const radius = 0.003; // ~300m offset
                    offsetLat = Math.cos(angle) * radius;
                    offsetLng = Math.sin(angle) * radius;
                }
                
                const markerPos = [
                    stationCoords[s][0] + offsetLat,
                    stationCoords[s][1] + offsetLng
                ];
                
                const markerSize = totalVehiclesAtStation > 1 ? 26 : 24;
                
                const m = L.marker(markerPos, {
                    icon: L.divIcon({
                        html: `<div style="
                            background:${color};
                            width:${markerSize}px;
                            height:${markerSize}px;
                            border-radius:50%;
                            border:3px solid white;
                            display:flex;
                            align-items:center;
                            justify-content:center;
                            font-weight:bold;
                            color:white;
                            font-size:10px;
                            box-shadow:0 2px 6px rgba(0,0,0,0.4);
                        ">${stopNum}</div>`,
                        iconSize: [markerSize, markerSize],
                        iconAnchor: [markerSize/2, markerSize/2]
                    })
                }).addTo(routesMap);
                routeAnimationLayers.push(m);
                
                // Popup'ta çoklu araç bilgisi
                let popupContent = `<b style="color:${color}">${stopNum}. Durak</b><br><strong>${s}</strong><br><small>Araç ${v.vehicle_id}</small>`;
                if (totalVehiclesAtStation > 1) {
                    popupContent += `<br><small class="text-muted"><i class="fas fa-info-circle"></i> Bu istasyona ${totalVehiclesAtStation} araç geliyor</small>`;
                }
                m.bindPopup(popupContent);
            }
        });

        // Legend'a araç bilgisi ekle
        const routeStr = (v.route || []).filter(s => s !== 'Umuttepe').join(' → ');
        legend.innerHTML += `
            <div class="mb-2 p-2 rounded" style="background:${color}15;border-left:4px solid ${color};">
                <div class="d-flex align-items-center justify-content-between mb-1">
                    <strong style="color:${color};">
                        <i class="fas fa-truck"></i> Araç ${v.vehicle_id} ${isRental ? '🔑 Kiralık' : '🚛 Özmal'}
                    </strong>
                </div>
                <div class="small">
                    <div><i class="fas fa-road text-muted"></i> <strong>${distance.toFixed(2)} km</strong> mesafe</div>
                    <div><i class="fas fa-box text-muted"></i> <strong>${load} kg</strong> taşıdı (Kalan: ${capacityLeft} kg)</div>
                    <div><i class="fas fa-map-marker-alt text-muted"></i> <strong>${routeStops}</strong> durak</div>
                    <div class="text-muted mt-1" style="font-size:11px;"><i class="fas fa-route"></i> ${routeStr || 'Rota yok'}</div>
                </div>
            </div>
        `;
    });

    // Harita sınırlarını ayarla
    const all = [];
    vehicles.forEach(v => {
        if (v.path_coords?.length) all.push(...v.path_coords);
        else v.route.forEach(s => stationCoords[s] && all.push(stationCoords[s]));
    });
    if (all.length) routesMap.fitBounds(all, {padding: [40, 40]});

    // Routes sekmesine geç
    document.querySelector('[data-tab="routes-view"]').click();
    setTimeout(() => routesMap.invalidateSize(), 100);
    
    // Raporları güncelle
    updateReports(vehicles);
}

// ==================== RAPORLAR VE GRAFİKLER ====================

let vehicleUsageChart = null;
let scenarioComparisonChart = null;

function updateReports(vehicles) {
    // Araç kullanım oranı grafiği
    updateVehicleUsageChart(vehicles);
    
    // Senaryo karşılaştırma grafiği
    updateScenarioChart();
    
    // Özet tablo
    updateSummaryTable();
    
    // Araç detay kartları
    updateVehicleDetailCards(vehicles);
}

function updateVehicleUsageChart(vehicles) {
    const ctx = document.getElementById('vehicle-usage-chart');
    if (!ctx) return;
    
    const vehicleColors = ['#e74c3c', '#3498db', '#2ecc71', '#9b59b6', '#f39c12', '#1abc9c'];
    
    const labels = vehicles.map(v => `Araç ${v.vehicle_id}`);
    const loads = vehicles.map(v => v.load || 0);
    const capacities = vehicles.map(v => v.capacity || 750);
    const remaining = vehicles.map((v, i) => capacities[i] - loads[i]);
    
    if (vehicleUsageChart) {
        vehicleUsageChart.destroy();
    }
    
    vehicleUsageChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Taşınan (kg)',
                    data: loads,
                    backgroundColor: vehicleColors.slice(0, vehicles.length),
                    borderWidth: 1
                },
                {
                    label: 'Boş Kapasite (kg)',
                    data: remaining,
                    backgroundColor: 'rgba(200, 200, 200, 0.5)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            scales: {
                x: { stacked: true },
                y: { stacked: true, beginAtZero: true }
            },
            plugins: {
                title: {
                    display: true,
                    text: 'Araç Doluluk Oranları'
                }
            }
        }
    });
}

function updateScenarioChart() {
    const ctx = document.getElementById('scenario-comparison-chart');
    if (!ctx) return;
    
    const scenarios = [];
    
    if (window.lastUnlimitedResult?.all_scenarios) {
        scenarios.push(...window.lastUnlimitedResult.all_scenarios);
    }
    if (window.lastLimitedResult?.all_scenarios) {
        scenarios.push(...window.lastLimitedResult.all_scenarios);
    }
    
    if (scenarios.length === 0) return;
    
    // Maliyete göre sırala
    scenarios.sort((a, b) => a.total_cost - b.total_cost);
    
    const labels = scenarios.map(s => s.name);
    const costs = scenarios.map(s => s.total_cost);
    const colors = scenarios.map((s, i) => i === 0 ? '#27ae60' : '#3498db');
    
    if (scenarioComparisonChart) {
        scenarioComparisonChart.destroy();
    }
    
    scenarioComparisonChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Toplam Maliyet',
                data: costs,
                backgroundColor: colors,
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Senaryo Maliyet Karşılaştırması (En düşük = En iyi)'
                },
                legend: { display: false }
            }
        }
    });
}

function updateSummaryTable() {
    const tbody = document.getElementById('summary-table-body');
    if (!tbody) return;
    
    const scenarios = [];
    
    if (window.lastUnlimitedResult?.all_scenarios) {
        scenarios.push(...window.lastUnlimitedResult.all_scenarios);
    }
    if (window.lastLimitedResult?.all_scenarios) {
        window.lastLimitedResult.all_scenarios.forEach(s => {
            if (!scenarios.find(x => x.name === s.name)) {
                scenarios.push(s);
            }
        });
    }
    
    if (scenarios.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Henüz hesaplama yapılmadı</td></tr>';
        return;
    }
    
    // Maliyete göre sırala
    scenarios.sort((a, b) => a.total_cost - b.total_cost);
    
    let html = '';
    scenarios.forEach((s, i) => {
        const totalDistance = (s.vehicles || []).reduce((sum, v) => sum + (v.distance_km || 0), 0);
        const isBest = i === 0;
        
        html += `
            <tr class="${isBest ? 'table-success' : ''}">
                <td>${isBest ? '⭐ ' : ''}${s.name}</td>
                <td>${s.vehicle_count || 0}</td>
                <td>${s.rental_count || 0}</td>
                <td>${totalDistance.toFixed(2)}</td>
                <td><strong>${s.total_cost.toFixed(2)}</strong></td>
                <td>${isBest ? '<span class="badge bg-success">En İyi</span>' : ''}</td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

function updateVehicleDetailCards(vehicles) {
    const container = document.getElementById('vehicle-detail-cards');
    if (!container) return;
    
    const vehicleColors = ['#e74c3c', '#3498db', '#2ecc71', '#9b59b6', '#f39c12', '#1abc9c'];
    
    if (!vehicles || vehicles.length === 0) {
        container.innerHTML = '<div class="col-12 text-center text-muted"><p>Araç verisi bulunamadı.</p></div>';
        return;
    }
    
    let html = '';
    vehicles.forEach((v, idx) => {
        const color = vehicleColors[idx % vehicleColors.length];
        const capacityLeft = (v.capacity || 750) - (v.load || 0);
        const pct = (((v.load || 0) / (v.capacity || 750)) * 100).toFixed(0);
        const routeStops = (v.route || []).filter(s => s !== 'Umuttepe');
        const isRental = v.type === 'kiralik';
        
        html += `
            <div class="col-md-4 mb-3">
                <div class="card h-100" style="border-top: 4px solid ${color};">
                    <div class="card-header" style="background: ${color}15;">
                        <h5 class="mb-0" style="color: ${color};">
                            <i class="fas fa-truck"></i> Araç ${v.vehicle_id}
                            <span class="badge ${isRental ? 'bg-warning' : 'bg-success'} float-end">
                                ${isRental ? '🔑 Kiralık' : '🚛 Özmal'}
                            </span>
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center mb-3">
                            <div class="col-6">
                                <div class="h4 mb-0" style="color: ${color};">${(v.distance_km || 0).toFixed(2)}</div>
                                <small class="text-muted">km mesafe</small>
                            </div>
                            <div class="col-6">
                                <div class="h4 mb-0" style="color: ${color};">${(v.cost || 0).toFixed(2)}</div>
                                <small class="text-muted">birim maliyet</small>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <small>Doluluk</small>
                                <small><strong>${v.load || 0}</strong> / ${v.capacity || 750} kg</small>
                            </div>
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" style="width: ${pct}%; background: ${color};"></div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <h6><i class="fas fa-route"></i> Rota (${routeStops.length} durak)</h6>
                            <div class="bg-light p-2 rounded small">
                                ${routeStops.map((s, i) => `<span class="badge" style="background:${color};color:white;">${i+1}</span> ${s}`).join(' → ') || '<span class="text-muted">Rota yok</span>'}
                            </div>
                        </div>
                        
                        <div>
                            <h6><i class="fas fa-users"></i> Kargo Sahipleri</h6>
                            <div id="vehicle-${v.vehicle_id}-users" class="small">
                                <span class="text-muted">Yükleniyor...</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    
    // Her araç için kullanıcı bilgilerini yükle
    vehicles.forEach(v => {
        loadVehicleUsers(v.vehicle_id);
    });
}

function loadVehicleUsers(vehicleId) {
    fetch(`/api/vehicle-details/${vehicleId}`)
        .then(res => res.json())
        .then(data => {
            const container = document.getElementById(`vehicle-${vehicleId}-users`);
            if (!container) return;
            
            if (data.assigned_cargos && data.assigned_cargos.length > 0) {
                const userList = data.assigned_cargos.map(c => 
                    `<div class="border-bottom py-1">
                        <i class="fas fa-user"></i> <strong>${c.username}</strong>
                        <br><small class="text-muted">${c.station} - ${c.weight}kg</small>
                    </div>`
                ).join('');
                container.innerHTML = userList;
            } else {
                container.innerHTML = '<span class="text-muted">Henüz kargo atanmadı</span>';
            }
        })
        .catch(err => {
            const container = document.getElementById(`vehicle-${vehicleId}-users`);
            if (container) {
                container.innerHTML = '<span class="text-muted">Bilgi alınamadı</span>';
            }
        });
}

// ==================== KAYITLI ROTALAR ====================

let savedRoutesData = [];
let routesFirstLoad = true; // İlk yükleme kontrolü

function loadSavedRoutes() {
    // Sonsuz döngüyü önle
    if (isLoadingRoutes) return;
    isLoadingRoutes = true;
    
    const container = document.getElementById('saved-routes-list');
    if (!container) {
        isLoadingRoutes = false;
        return;
    }
    
    container.innerHTML = '<div class="text-center text-muted py-3"><i class="fas fa-spinner fa-spin"></i> Yükleniyor...</div>';
    
    fetch('/api/routes', {
        method: 'GET',
        credentials: 'same-origin',
        headers: {
            'Accept': 'application/json'
        }
    })
        .then(res => {
            if (!res.ok) {
                throw new Error('API yanıt vermedi');
            }
            return res.json();
        })
        .then(data => {
            if (!data.success || !data.routes || data.routes.length === 0) {
                container.innerHTML = '<div class="text-center text-muted py-3"><i class="fas fa-info-circle"></i> Henüz kayıtlı rota yok</div>';
                isLoadingRoutes = false;
                return;
            }
            
            savedRoutesData = data.routes;
            
            let html = '';
            data.routes.forEach((route, index) => {
                const totalDistance = route.vehicles.reduce((sum, v) => sum + (v.distance_km || 0), 0);
                const rentalCount = route.vehicles.filter(v => v.type === 'kiralik').length;
                
                html += `
                    <div class="route-item card mb-2" data-route-id="${route.id}">
                        <div class="card-body p-2">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><i class="fas fa-route"></i> Rota #${route.id}</strong>
                                    <br><small class="text-muted">${route.calculated_at}</small>
                                </div>
                                <div class="text-end">
                                    <span class="badge bg-primary">${route.vehicle_count} araç</span>
                                    ${rentalCount > 0 ? `<span class="badge bg-warning">${rentalCount} kiralık</span>` : ''}
                                </div>
                            </div>
                            <div class="row text-center mt-2 small">
                                <div class="col-6">
                                    <span class="text-success"><strong>${route.total_cost.toFixed(2)}</strong></span>
                                    <br><small class="text-muted">Maliyet</small>
                                </div>
                                <div class="col-6">
                                    <span class="text-info"><strong>${totalDistance.toFixed(2)} km</strong></span>
                                    <br><small class="text-muted">Mesafe</small>
                                </div>
                            </div>
                            <div class="mt-2 d-flex gap-1">
                                <button class="btn btn-sm btn-outline-primary flex-grow-1 view-route-btn" data-route-id="${route.id}">
                                    <i class="fas fa-eye"></i> Görüntüle
                                </button>
                                <button class="btn btn-sm btn-outline-danger delete-route-btn" data-route-id="${route.id}">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            container.innerHTML = html;
            
            // Event listeners - event delegation kullan (tekrar eklemeyi önler)
            container.onclick = function(e) {
                const viewBtn = e.target.closest('.view-route-btn');
                const deleteBtn = e.target.closest('.delete-route-btn');
                
                if (viewBtn) {
                    e.preventDefault();
                    e.stopPropagation();
                    const routeId = parseInt(viewBtn.dataset.routeId);
                    viewSavedRoute(routeId);
                } else if (deleteBtn) {
                    e.preventDefault();
                    e.stopPropagation();
                    const routeId = parseInt(deleteBtn.dataset.routeId);
                    deleteSavedRoute(routeId);
                }
            };
            
            // Sadece ilk yüklemede ilk rotayı göster
            if (routesFirstLoad && data.routes.length > 0) {
                routesFirstLoad = false;
                viewSavedRoute(data.routes[0].id);
            }
            
            isLoadingRoutes = false;
        })
        .catch(err => {
            console.error('Rotalar yüklenemedi:', err);
            container.innerHTML = '<div class="text-center text-danger py-3"><i class="fas fa-exclamation-triangle"></i> Yükleme hatası</div>';
            isLoadingRoutes = false;
        });
}

function viewSavedRoute(routeId) {
    const route = savedRoutesData.find(r => r.id === routeId);
    if (!route) return;
    
    // Aktif route'u işaretle
    document.querySelectorAll('.route-item').forEach(item => {
        item.classList.remove('border-primary');
        if (parseInt(item.dataset.routeId) === routeId) {
            item.classList.add('border-primary');
        }
    });
    
    // Haritada göster
    if (route.vehicles && route.vehicles.length > 0) {
        drawRealRoutesOnMap(route.vehicles);
    }
    
    // Detay panelini göster
    const detailsPanel = document.getElementById('selected-route-details');
    const titleSpan = document.getElementById('selected-route-title');
    const vehiclesContainer = document.getElementById('selected-route-vehicles');
    
    if (detailsPanel && titleSpan && vehiclesContainer) {
        detailsPanel.style.display = 'block';
        titleSpan.textContent = `Rota #${route.id} - ${route.calculated_at}`;
        
        const vehicleColors = ['#e74c3c', '#3498db', '#2ecc71', '#9b59b6', '#f39c12', '#1abc9c'];
        
        let html = '';
        route.vehicles.forEach((v, idx) => {
            const color = vehicleColors[idx % vehicleColors.length];
            const routeStops = (v.route || []).filter(s => s !== 'Umuttepe');
            const isRental = v.type === 'kiralik';
            const pct = ((v.load / v.capacity) * 100).toFixed(0);
            
            html += `
                <div class="col-md-4 mb-3">
                    <div class="card h-100" style="border-left: 4px solid ${color};">
                        <div class="card-body p-2">
                            <h6 style="color: ${color};">
                                <i class="fas fa-truck"></i> Araç ${v.vehicle_id}
                                <span class="badge ${isRental ? 'bg-warning' : 'bg-success'} float-end" style="font-size: 0.7em;">
                                    ${isRental ? 'Kiralık' : 'Özmal'}
                                </span>
                            </h6>
                            <div class="row text-center small mb-2">
                                <div class="col-4">
                                    <strong style="color: ${color};">${v.distance_km?.toFixed(1) || 0}</strong>
                                    <br><small class="text-muted">km</small>
                                </div>
                                <div class="col-4">
                                    <strong style="color: ${color};">${v.load || 0}</strong>
                                    <br><small class="text-muted">kg</small>
                                </div>
                                <div class="col-4">
                                    <strong style="color: ${color};">${v.cost?.toFixed(1) || 0}</strong>
                                    <br><small class="text-muted">maliyet</small>
                                </div>
                            </div>
                            <div class="progress mb-2" style="height: 5px;">
                                <div class="progress-bar" style="width: ${pct}%; background: ${color};"></div>
                            </div>
                            <small class="text-muted">Rota: </small>
                            <small>${routeStops.map((s, i) => `<span style="color:${color};">${i+1}.</span>${s}`).join(' → ') || '-'}</small>
                        </div>
                    </div>
                </div>
            `;
        });
        
        vehiclesContainer.innerHTML = html;
    }
}

function deleteSavedRoute(routeId) {
    if (!confirm(`Rota #${routeId} silinecek. Bu rotaya atanmış kargolar tekrar "beklemede" durumuna alınacak. Devam edilsin mi?`)) {
        return;
    }
    
    fetch(`/api/routes/${routeId}`, { method: 'DELETE' })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                loadSavedRoutes();
                // Detay panelini gizle
                const detailsPanel = document.getElementById('selected-route-details');
                if (detailsPanel) detailsPanel.style.display = 'none';
                // Haritayı temizle
                clearRoutesMap();
            } else {
                alert('Silme hatası: ' + (data.error || 'Bilinmeyen hata'));
            }
        })
        .catch(err => {
            console.error('Silme hatası:', err);
            alert('Silme sırasında hata oluştu');
        });
}

function clearRoutesMap() {
    if (routesMap) {
        routeAnimationLayers.forEach(layer => routesMap.removeLayer(layer));
        routeAnimationLayers = [];
    }
}
