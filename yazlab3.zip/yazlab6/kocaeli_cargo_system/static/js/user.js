// User Panel JavaScript - OSRM ile Gerçek Yol Rotası

document.addEventListener('DOMContentLoaded', function() {
    // Initialize User Map
    initUserMap();

    // View Route Buttons
    document.querySelectorAll('.view-route').forEach(btn => {
        btn.addEventListener('click', function() {
            const cargoId = this.dataset.cargoId;
            loadCargoRoute(cargoId);
        });
    });
});

// Kocaeli ilçe koordinatları
const stationCoords = {
    'Umuttepe': [40.822, 29.922],
    'Basiskele': [40.715, 29.928],
    'Cayirova': [40.815, 29.375],
    'Darica': [40.773, 29.400],
    'Derince': [40.756, 29.830],
    'Dilovasi': [40.787, 29.544],
    'Gebze': [40.802, 29.430],
    'Golcuk': [40.717, 29.820],
    'Kandira': [41.070, 30.150],
    'Karamursel': [40.692, 29.615],
    'Kartepe': [40.753, 30.020],
    'Korfez': [40.765, 29.780],
    'Izmit': [40.766, 29.940]
};

// Renk paleti - her araç için farklı renk
const routeColors = [
    '#e74c3c', // Kırmızı
    '#3498db', // Mavi
    '#27ae60', // Yeşil
    '#9b59b6', // Mor
    '#f39c12', // Turuncu
    '#1abc9c'  // Turkuaz
];

let userMap = null;
let routeLayers = []; // Eklenen rotaları takip etmek için

function initUserMap() {
    userMap = L.map('user-cargo-map').setView([40.78, 29.75], 10);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors | OSRM Routing'
    }).addTo(userMap);

    // Merkez marker - Umuttepe
    const umuttepeIcon = L.divIcon({
        html: '<div style="background: #e74c3c; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"><i class="fas fa-university"></i></div>',
        className: 'custom-div-icon',
        iconSize: [30, 30],
        iconAnchor: [15, 15]
    });

    L.marker(stationCoords['Umuttepe'], { icon: umuttepeIcon })
        .addTo(userMap)
        .bindPopup('<b>🏫 Kocaeli Üniversitesi</b><br>Merkez Depo - Umuttepe');

    // Tüm istasyonları göster
    for (const [name, coords] of Object.entries(stationCoords)) {
        if (name !== 'Umuttepe') {
            L.circleMarker(coords, {
                radius: 8,
                fillColor: '#3498db',
                color: '#fff',
                weight: 2,
                fillOpacity: 0.8
            }).addTo(userMap).bindPopup(`<b>📍 ${name}</b><br>Teslimat İstasyonu`);
        }
    }
}

// OSRM API ile gerçek yol rotası al
async function getOSRMRoute(coordinates) {
    // Koordinatları OSRM formatına çevir (lon,lat)
    const coordString = coordinates.map(c => `${c[1]},${c[0]}`).join(';');
    const url = `https://router.project-osrm.org/route/v1/driving/${coordString}?overview=full&geometries=geojson&steps=true`;
    
    try {
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.code === 'Ok' && data.routes && data.routes.length > 0) {
            return {
                success: true,
                geometry: data.routes[0].geometry,
                distance: data.routes[0].distance / 1000, // km
                duration: data.routes[0].duration / 60 // dakika
            };
        }
        return { success: false };
    } catch (error) {
        console.error('OSRM API hatası:', error);
        return { success: false };
    }
}

// İki nokta arası OSRM rotası çiz
async function drawRealRoute(from, to, color, layerGroup) {
    const fromCoords = stationCoords[from];
    const toCoords = stationCoords[to];
    
    if (!fromCoords || !toCoords) return null;
    
    const routeData = await getOSRMRoute([fromCoords, toCoords]);
    
    if (routeData.success) {
        // GeoJSON formatındaki rotayı çiz
        const routeCoords = routeData.geometry.coordinates.map(c => [c[1], c[0]]);
        
        const polyline = L.polyline(routeCoords, {
            color: color,
            weight: 5,
            opacity: 0.8,
            smoothFactor: 1
        });
        
        layerGroup.addLayer(polyline);
        
        return {
            distance: routeData.distance,
            duration: routeData.duration,
            coords: routeCoords
        };
    }
    
    // Fallback: düz çizgi (asla kuş uçuşu olmaması için uyarı göster)
    console.warn(`OSRM rotası alınamadı: ${from} → ${to}`);
    return null;
}

function loadCargoRoute(cargoId) {
    // Loading göster
    const infoPanel = document.getElementById('cargo-info-panel');
    infoPanel.className = 'alert alert-warning';
    infoPanel.innerHTML = `
        <h6><i class="fas fa-spinner fa-spin"></i> Güzergah Yükleniyor...</h6>
        <p>OSRM API'den gerçek yol rotası alınıyor...</p>
    `;
    
    // API'den kargo rotasını al
    fetch(`/api/cargo/${cargoId}/route`)
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                showMockRoute(cargoId);
            } else {
                displayCargoRoute(data);
            }
        })
        .catch(err => {
            console.error(err);
            showMockRoute(cargoId);
        });
}

async function showMockRoute(cargoId) {
    // Demo rota göster - GERÇEK YOLLAR İLE
    const infoPanel = document.getElementById('cargo-info-panel');
    infoPanel.className = 'alert alert-warning';
    infoPanel.innerHTML = `
        <h6><i class="fas fa-spinner fa-spin"></i> Güzergah Hesaplanıyor...</h6>
        <p>OSRM API ile gerçek sokak rotası çiziliyor...</p>
    `;

    // Haritayı temizle
    clearMapRoutes();
    
    // Demo rota
    const route = ['Gebze', 'Darica', 'Dilovasi', 'Izmit', 'Umuttepe'];
    const color = routeColors[0];
    
    // Rota layer grubu
    const routeLayerGroup = L.layerGroup().addTo(userMap);
    routeLayers.push(routeLayerGroup);
    
    let totalDistance = 0;
    let totalDuration = 0;
    let allCoords = [];
    
    // Her segment için OSRM rotası al
    for (let i = 0; i < route.length - 1; i++) {
        const from = route[i];
        const to = route[i + 1];
        
        const segmentData = await drawRealRoute(from, to, color, routeLayerGroup);
        
        if (segmentData) {
            totalDistance += segmentData.distance;
            totalDuration += segmentData.duration;
            allCoords = allCoords.concat(segmentData.coords);
        }
    }
    
    // İstasyon markerları ekle
    route.forEach((station, idx) => {
        if (stationCoords[station]) {
            const isStart = idx === 0;
            const isEnd = idx === route.length - 1;
            
            let markerColor = '#f39c12'; // Ara durak
            let markerSize = 10;
            let label = `${idx + 1}`;
            
            if (isStart) {
                markerColor = '#27ae60'; // Başlangıç - Yeşil
                markerSize = 14;
                label = '🚀';
            } else if (isEnd) {
                markerColor = '#e74c3c'; // Bitiş - Kırmızı
                markerSize = 14;
                label = '🏁';
            }
            
            const marker = L.circleMarker(stationCoords[station], {
                radius: markerSize,
                fillColor: markerColor,
                color: '#fff',
                weight: 3,
                fillOpacity: 1
            }).bindPopup(`
                <b>${isStart ? '🚀 Başlangıç' : isEnd ? '🏁 Bitiş' : `📍 Durak ${idx}`}</b><br>
                ${station}
            `);
            
            routeLayerGroup.addLayer(marker);
        }
    });

    // Haritayı sığdır
    if (allCoords.length > 0) {
        userMap.fitBounds(allCoords, { padding: [30, 30] });
    }
    
    // Bilgi panelini güncelle
    infoPanel.className = 'alert alert-success';
    infoPanel.innerHTML = `
        <h6><i class="fas fa-truck"></i> Kargo #${cargoId} Güzergah Bilgisi</h6>
        <div class="row">
            <div class="col-md-6">
                <p><strong>🚗 Araç:</strong> Araç 1 (1000kg Özmal)</p>
                <p><strong>📍 Rota:</strong> ${route.join(' → ')}</p>
            </div>
            <div class="col-md-6">
                <p><strong>📏 Toplam Mesafe:</strong> ${totalDistance.toFixed(2)} km</p>
                <p><strong>⏱️ Tahmini Süre:</strong> ${Math.round(totalDuration)} dakika</p>
            </div>
        </div>
        <div class="mt-2">
            <span class="badge bg-success"><i class="fas fa-road"></i> Gerçek Yol Rotası (OSRM)</span>
            <span class="badge bg-info"><i class="fas fa-map-marker-alt"></i> ${route.length} Durak</span>
        </div>
    `;
}

async function displayCargoRoute(data) {
    const infoPanel = document.getElementById('cargo-info-panel');
    infoPanel.className = 'alert alert-warning';
    infoPanel.innerHTML = `
        <h6><i class="fas fa-spinner fa-spin"></i> Güzergah Yükleniyor...</h6>
        <p>Kargonuzun güzergahı gösteriliyor...</p>
    `;

    // Haritayı temizle
    clearMapRoutes();
    
    const route = data.route || [];
    const pathCoords = data.path_coords || [];
    const color = '#3498db'; // Kullanıcı için mavi
    
    if (route.length < 2) {
        infoPanel.className = 'alert alert-info';
        infoPanel.innerHTML = `
            <h6><i class="fas fa-info-circle"></i> Kargo #${data.cargo_id}</h6>
            <p><strong>İstasyon:</strong> ${data.station_name || 'Belirlenmedi'}</p>
            <p>${data.message || 'Bu kargo için henüz güzergah belirlenmedi. Rota planlaması yapıldıktan sonra güzergah bilgisi burada görünecektir.'}</p>
        `;
        return;
    }
    
    // Rota layer grubu
    const routeLayerGroup = L.layerGroup().addTo(userMap);
    routeLayers.push(routeLayerGroup);
    
    let totalDistance = data.distance_km || 0;
    let allCoords = [];
    
    // Eğer path_coords varsa direkt kullan (backend'den OSRM ile hesaplanmış)
    if (pathCoords.length > 0) {
        // Gölge çizgi
        const shadowLine = L.polyline(pathCoords, {
            color: '#000',
            weight: 8,
            opacity: 0.2
        });
        routeLayerGroup.addLayer(shadowLine);
        
        // Ana çizgi
        const mainLine = L.polyline(pathCoords, {
            color: color,
            weight: 5,
            opacity: 0.9
        });
        routeLayerGroup.addLayer(mainLine);
        
        allCoords = pathCoords;
    } else {
        // OSRM API ile çiz
        for (let i = 0; i < route.length - 1; i++) {
            const from = route[i];
            const to = route[i + 1];
            
            const segmentData = await drawRealRoute(from, to, color, routeLayerGroup);
            
            if (segmentData) {
                totalDistance += segmentData.distance;
                allCoords = allCoords.concat(segmentData.coords);
            }
        }
    }
    
    // Kullanıcının kargosunun gideceği istasyonu vurgula
    const userStation = data.station_name;
    
    // İstasyon markerları ekle
    route.forEach((station, idx) => {
        if (stationCoords[station]) {
            const isUserStation = station === userStation;
            const isStart = station === 'Umuttepe' && idx === route.length - 1;
            const isFirstStop = idx === 0;
            
            let markerColor = '#95a5a6'; // Diğer duraklar - gri
            let markerSize = 8;
            let markerLabel = '';
            
            if (isUserStation) {
                markerColor = '#e74c3c'; // Kullanıcının istasyonu - kırmızı
                markerSize = 16;
                markerLabel = '📦';
            } else if (isStart) {
                markerColor = '#27ae60'; // Merkez - yeşil
                markerSize = 14;
                markerLabel = '🏁';
            } else if (isFirstStop) {
                markerColor = '#f39c12'; // İlk durak - turuncu
                markerSize = 12;
            }
            
            const marker = L.marker(stationCoords[station], {
                icon: L.divIcon({
                    html: `<div style="
                        background:${markerColor};
                        width:${markerSize * 2}px;
                        height:${markerSize * 2}px;
                        border-radius:50%;
                        border:3px solid white;
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        font-size:${markerSize}px;
                        box-shadow:0 2px 6px rgba(0,0,0,0.3);
                        color:white;
                        font-weight:bold;
                    ">${markerLabel || (idx + 1)}</div>`,
                    iconSize: [markerSize * 2, markerSize * 2],
                    iconAnchor: [markerSize, markerSize]
                })
            }).bindPopup(`
                <b>${isUserStation ? '📦 Kargonuzun Teslim Noktası' : isStart ? '🏁 Merkez' : `📍 ${idx + 1}. Durak`}</b><br>
                <strong>${station}</strong>
                ${isUserStation ? '<br><span class="badge bg-danger">Kargonuz Burada!</span>' : ''}
            `);
            
            routeLayerGroup.addLayer(marker);
            
            // Kullanıcının istasyonunu otomatik aç
            if (isUserStation) {
                marker.openPopup();
            }
        }
    });

    // Haritayı sığdır
    if (allCoords.length > 0) {
        userMap.fitBounds(allCoords, { padding: [50, 50] });
    }
    
    // Kullanıcının istasyonunun kaçıncı durak olduğunu bul
    const userStopIndex = route.indexOf(userStation);
    const totalStops = route.filter(s => s !== 'Umuttepe').length;
    
    // Bilgi panelini güncelle
    infoPanel.className = 'alert alert-success';
    infoPanel.innerHTML = `
        <h6><i class="fas fa-truck"></i> Kargo #${data.cargo_id} - Güzergah Bilgisi</h6>
        <div class="row">
            <div class="col-md-6">
                <p><strong>🚗 Taşıyan Araç:</strong> ${data.vehicle_info || 'Araç ' + data.vehicle_id}</p>
                <p><strong>📍 Teslim Noktası:</strong> <span class="text-danger fw-bold">${userStation}</span></p>
                <p><strong>🔢 Teslimat Sırası:</strong> ${userStopIndex > 0 ? userStopIndex : '?'} / ${totalStops} durak</p>
            </div>
            <div class="col-md-6">
                <p><strong>📏 Araç Toplam Mesafe:</strong> ${totalDistance.toFixed(2)} km</p>
                <p><strong>📦 Araç Kapasitesi:</strong> ${data.vehicle_capacity || '?'} kg</p>
                <p><strong>📊 Araç Yükü:</strong> ${data.vehicle_load || '?'} kg</p>
            </div>
        </div>
        <div class="mt-2">
            <span class="badge bg-primary"><i class="fas fa-road"></i> Gerçek Yol Rotası</span>
            <span class="badge bg-info"><i class="fas fa-map-marker-alt"></i> ${totalStops} Teslimat Noktası</span>
            <span class="badge bg-${data.status === 'delivered' ? 'success' : data.status === 'assigned' ? 'warning' : 'secondary'}">
                ${data.status === 'delivered' ? '✅ Teslim Edildi' : data.status === 'assigned' ? '🚚 Araç Atandı' : '⏳ Beklemede'}
            </span>
        </div>
        <div class="alert alert-info mt-3 mb-0">
            <small><i class="fas fa-info-circle"></i> 
            <strong>Not:</strong> Sadece kargonuzun taşındığı aracın güzergahını görebilirsiniz. 
            Diğer araçların güzergah bilgileri gizlidir.</small>
        </div>
    `;
}

function clearMapRoutes() {
    // Önceki rotaları temizle
    routeLayers.forEach(layer => {
        userMap.removeLayer(layer);
    });
    routeLayers = [];
    
    // Ayrıca tüm polyline ve circle markerları temizle
    userMap.eachLayer(layer => {
        if (layer instanceof L.Polyline && !(layer instanceof L.Polygon)) {
            userMap.removeLayer(layer);
        }
    });
}
